from sqlalchemy import Column, Integer, ForeignKey, Boolean, TIMESTAMP, func
from sqlalchemy.orm import relationship
from app.db.base import BaseOrg

class ClassSubjectMap(BaseOrg):
    __tablename__ = 'class_subject_mappings'
    
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    class_id = Column(Integer, ForeignKey('classes.id'), nullable=False)
    subject_id = Column(Integer, ForeignKey('subjects.id'), nullable=False)
    is_active = Column(Boolean, default=True)
    created_at = Column(TIMESTAMP, nullable=False, server_default=func.now())
    updated_at = Column(TIMESTAMP, nullable=False, server_default=func.now(), onupdate=func.now())
    
    # Relationships
    # class_ = relationship("Class", back_populates="subjects")
    # subject = relationship("Subject", back_populates="classes")
    # Academic Year relationship
    academic_year_id = Column(Integer, ForeignKey('academic_years.id'), nullable=False)
    academic_year = relationship("AcademicYear", back_populates="class_subject_mappings")
    
    class_ = relationship("Class", back_populates="class_subject_mappings")
    subject = relationship("Subject", back_populates="class_subject_mappings")
    
    def __repr__(self):
        return f"<ClassSubjectMap(id={self.id}, class_id={self.class_id}, subject_id={self.subject_id})>"    