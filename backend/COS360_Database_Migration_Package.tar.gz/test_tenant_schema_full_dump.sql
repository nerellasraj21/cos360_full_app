--
-- PostgreSQL database dump
--

-- Dumped from database version 17.5
-- Dumped by pg_dump version 17.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: test_tenant_schema; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA test_tenant_schema;


ALTER SCHEMA test_tenant_schema OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: academic_years; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.academic_years (
    id uuid NOT NULL,
    title character varying(50) NOT NULL,
    is_active boolean,
    start_date date NOT NULL,
    end_date date NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE test_tenant_schema.academic_years OWNER TO postgres;

--
-- Name: alembic_version; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE test_tenant_schema.alembic_version OWNER TO postgres;

--
-- Name: certificate_types; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.certificate_types (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(100) NOT NULL,
    description character varying(255)
);


ALTER TABLE test_tenant_schema.certificate_types OWNER TO postgres;

--
-- Name: class_subject_mappings; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.class_subject_mappings (
    id uuid NOT NULL,
    class_id uuid NOT NULL,
    subject_id uuid NOT NULL,
    is_active boolean,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    academic_year_id uuid NOT NULL,
    exclude_marks boolean DEFAULT false NOT NULL,
    "order" integer
);


ALTER TABLE test_tenant_schema.class_subject_mappings OWNER TO postgres;

--
-- Name: classes; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.classes (
    id uuid NOT NULL,
    name character varying(50) NOT NULL,
    description character varying(100),
    is_active boolean,
    short_code character varying(10),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    academic_year_id uuid NOT NULL
);


ALTER TABLE test_tenant_schema.classes OWNER TO postgres;

--
-- Name: designations; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.designations (
    id uuid NOT NULL,
    title character varying(100) NOT NULL
);


ALTER TABLE test_tenant_schema.designations OWNER TO postgres;

--
-- Name: expense_attachments; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.expense_attachments (
    id uuid NOT NULL,
    transaction_id uuid NOT NULL,
    original_filename character varying(255) NOT NULL,
    stored_filename character varying(255) NOT NULL,
    file_path character varying(500) NOT NULL,
    file_size bigint NOT NULL,
    mime_type character varying(100) NOT NULL,
    file_extension character varying(10) NOT NULL,
    file_hash_sha256 character varying(64) NOT NULL,
    virus_scan_status character varying(20) NOT NULL,
    virus_scan_result text,
    virus_scanned_at timestamp without time zone,
    is_public boolean,
    is_encrypted boolean,
    encryption_key_id character varying(100),
    document_type character varying(50) NOT NULL,
    is_verified boolean,
    verified_by_user_id uuid,
    verified_at timestamp without time zone,
    verification_notes text,
    retention_period_months integer NOT NULL,
    is_archived boolean,
    archived_at timestamp without time zone,
    can_be_deleted boolean,
    department_id uuid,
    uploaded_by_user_id uuid NOT NULL,
    uploaded_by_role character varying(50) NOT NULL,
    uploaded_at timestamp without time zone DEFAULT now() NOT NULL,
    last_accessed_at timestamp without time zone,
    access_count integer NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    org_id uuid NOT NULL
);


ALTER TABLE test_tenant_schema.expense_attachments OWNER TO postgres;

--
-- Name: expense_audit_logs; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.expense_audit_logs (
    id uuid NOT NULL,
    transaction_id uuid NOT NULL,
    action character varying(50) NOT NULL,
    action_category character varying(30) NOT NULL,
    field_name character varying(100),
    old_value text,
    new_value text,
    full_record_before json,
    full_record_after json,
    action_reason character varying(500),
    action_notes text,
    request_ip_address character varying(45),
    request_user_agent character varying(500),
    request_session_id character varying(100),
    api_endpoint character varying(200),
    http_method character varying(10),
    request_id character varying(100),
    workflow_stage character varying(50),
    compliance_flags json,
    department_id uuid,
    actor_user_id uuid NOT NULL,
    actor_role character varying(50) NOT NULL,
    actor_username character varying(100) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    org_id uuid NOT NULL
);


ALTER TABLE test_tenant_schema.expense_audit_logs OWNER TO postgres;

--
-- Name: expense_categories; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.expense_categories (
    id uuid NOT NULL,
    name character varying(100) NOT NULL,
    description character varying(300),
    is_active boolean,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    org_id uuid NOT NULL
);


ALTER TABLE test_tenant_schema.expense_categories OWNER TO postgres;

--
-- Name: expense_settings; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.expense_settings (
    id uuid NOT NULL,
    setting_key character varying(100) NOT NULL,
    setting_name character varying(200) NOT NULL,
    setting_description text,
    setting_category character varying(50) NOT NULL,
    string_value character varying(500),
    numeric_value numeric(15,2),
    integer_value integer,
    boolean_value boolean,
    "json_value" json,
    default_value text,
    is_system_setting boolean,
    is_user_configurable boolean,
    validation_rules json,
    allowed_values json,
    requires_approval boolean,
    approval_threshold numeric(10,2),
    department_id uuid,
    applies_to_all_departments boolean,
    is_audit_required boolean,
    is_sensitive boolean,
    compliance_level character varying(20),
    version integer NOT NULL,
    is_active boolean,
    effective_from timestamp without time zone,
    effective_until timestamp without time zone,
    created_by_user_id uuid NOT NULL,
    created_by_role character varying(50) NOT NULL,
    last_modified_by_user_id uuid,
    last_modified_by_role character varying(50),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    org_id uuid NOT NULL
);


ALTER TABLE test_tenant_schema.expense_settings OWNER TO postgres;

--
-- Name: expense_transaction_items; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.expense_transaction_items (
    id uuid NOT NULL,
    transaction_id uuid NOT NULL,
    item_name character varying(200) NOT NULL,
    item_description text,
    unit_price numeric(10,2) NOT NULL,
    quantity numeric(8,2) NOT NULL,
    total_price numeric(10,2) NOT NULL,
    item_category character varying(100),
    tax_rate numeric(5,2),
    tax_amount numeric(10,2),
    discount_rate numeric(5,2),
    discount_amount numeric(10,2),
    final_amount numeric(10,2) NOT NULL,
    vendor_item_code character varying(100),
    vendor_item_reference character varying(100),
    created_by_user_id uuid NOT NULL,
    created_by_role character varying(50) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    org_id uuid NOT NULL
);


ALTER TABLE test_tenant_schema.expense_transaction_items OWNER TO postgres;

--
-- Name: expense_transactions; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.expense_transactions (
    id uuid NOT NULL,
    expense_type_id uuid NOT NULL,
    amount numeric(10,2) NOT NULL,
    transaction_date date NOT NULL,
    description character varying(500) NOT NULL,
    reference_number character varying(100),
    idempotency_key character varying(100) NOT NULL,
    payment_method character varying(20) NOT NULL,
    vendor_name character varying(200),
    status character varying(20) NOT NULL,
    requires_approval boolean,
    requires_approval_override boolean,
    approved_by_user_id uuid,
    approved_by_role character varying(50),
    approved_at timestamp without time zone,
    approval_comment character varying(500),
    department_id uuid,
    version integer NOT NULL,
    created_by_user_id uuid NOT NULL,
    created_by_role character varying(50) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    org_id uuid NOT NULL
);


ALTER TABLE test_tenant_schema.expense_transactions OWNER TO postgres;

--
-- Name: expense_types; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.expense_types (
    id uuid NOT NULL,
    name character varying(100) NOT NULL,
    category_id uuid NOT NULL,
    description character varying(300),
    is_active boolean,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    org_id uuid NOT NULL
);


ALTER TABLE test_tenant_schema.expense_types OWNER TO postgres;

--
-- Name: fee_categories; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.fee_categories (
    id uuid NOT NULL,
    category_name character varying(100) NOT NULL,
    category_status character varying(20) NOT NULL,
    academic_year_id uuid NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE test_tenant_schema.fee_categories OWNER TO postgres;

--
-- Name: fee_class_map_term_amounts; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.fee_class_map_term_amounts (
    id uuid NOT NULL,
    fee_class_mapping_id uuid NOT NULL,
    term_id uuid NOT NULL,
    term_amount numeric(10,2) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE test_tenant_schema.fee_class_map_term_amounts OWNER TO postgres;

--
-- Name: fee_class_mappings; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.fee_class_mappings (
    id uuid NOT NULL,
    class_id uuid NOT NULL,
    fee_type_id uuid NOT NULL,
    total_fee numeric(10,2) NOT NULL,
    academic_year_id uuid NOT NULL,
    all_by_default boolean NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE test_tenant_schema.fee_class_mappings OWNER TO postgres;

--
-- Name: fee_receipts; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.fee_receipts (
    id uuid NOT NULL,
    receipt_number character varying(50) NOT NULL,
    fee_transaction_id uuid NOT NULL,
    student_name character varying(200) NOT NULL,
    student_admission_num character varying(50) NOT NULL,
    class_section character varying(100) NOT NULL,
    academic_year character varying(50) NOT NULL,
    content_hash character varying(64) NOT NULL,
    pdf_file_path character varying(500),
    is_reprinted boolean NOT NULL,
    reprint_count character varying DEFAULT '0'::character varying NOT NULL,
    generated_by_user_id uuid NOT NULL,
    remarks text,
    generated_at timestamp without time zone DEFAULT now() NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE test_tenant_schema.fee_receipts OWNER TO postgres;

--
-- Name: fee_refunds; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.fee_refunds (
    id uuid NOT NULL,
    refund_number character varying(50) NOT NULL,
    fee_transaction_id uuid NOT NULL,
    student_id uuid NOT NULL,
    student_admission_num character varying(50) NOT NULL,
    academic_year_id uuid NOT NULL,
    refund_amount numeric(10,2) NOT NULL,
    refund_reason character varying(20) NOT NULL,
    detailed_reason text,
    status character varying(20) NOT NULL,
    requested_by_user_id uuid NOT NULL,
    approved_by_user_id uuid,
    processed_by_user_id uuid,
    refund_method character varying(20),
    refund_reference character varying(100),
    approval_remarks text,
    processing_remarks text,
    requested_date timestamp without time zone DEFAULT now() NOT NULL,
    approved_date timestamp without time zone,
    processed_date timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE test_tenant_schema.fee_refunds OWNER TO postgres;

--
-- Name: fee_term_dates; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.fee_term_dates (
    id uuid NOT NULL,
    term_id uuid NOT NULL,
    fee_term_date date NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE test_tenant_schema.fee_term_dates OWNER TO postgres;

--
-- Name: fee_terms; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.fee_terms (
    id uuid NOT NULL,
    term_name character varying(50) NOT NULL,
    term_status character varying(20) NOT NULL,
    number_of_terms integer NOT NULL,
    academic_year_id uuid NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE test_tenant_schema.fee_terms OWNER TO postgres;

--
-- Name: fee_transaction_items; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.fee_transaction_items (
    id uuid NOT NULL,
    fee_transaction_id uuid NOT NULL,
    fee_type_id uuid NOT NULL,
    fee_term_id uuid NOT NULL,
    amount_due numeric(10,2) NOT NULL,
    amount_paid numeric(10,2) NOT NULL,
    description character varying(200),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE test_tenant_schema.fee_transaction_items OWNER TO postgres;

--
-- Name: fee_transactions; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.fee_transactions (
    id uuid NOT NULL,
    transaction_number character varying(50) NOT NULL,
    student_id uuid NOT NULL,
    student_admission_num character varying(50) NOT NULL,
    academic_year_id uuid NOT NULL,
    total_amount numeric(10,2) NOT NULL,
    payment_method character varying(20) NOT NULL,
    status character varying(20) NOT NULL,
    upi_reference character varying(100),
    upi_app_name character varying(50),
    cheque_number character varying(50),
    cheque_date timestamp without time zone,
    cheque_bank character varying(100),
    cheque_status character varying(20),
    bank_reference character varying(100),
    bank_name character varying(100),
    collected_by_user_id uuid NOT NULL,
    approved_by_user_id uuid,
    receipt_generated boolean NOT NULL,
    receipt_hash character varying(64),
    remarks text,
    transaction_date timestamp without time zone DEFAULT now() NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE test_tenant_schema.fee_transactions OWNER TO postgres;

--
-- Name: fee_types; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.fee_types (
    id uuid NOT NULL,
    type_name character varying(100) NOT NULL,
    fee_category_id uuid NOT NULL,
    fee_status character varying(20) NOT NULL,
    fee_term_id uuid NOT NULL,
    academic_year_id uuid NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE test_tenant_schema.fee_types OWNER TO postgres;

--
-- Name: holidays; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.holidays (
    id uuid NOT NULL,
    name character varying(50) NOT NULL,
    description character varying(100),
    start_date date NOT NULL,
    end_date date NOT NULL,
    is_active boolean,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    academic_year_id uuid NOT NULL
);


ALTER TABLE test_tenant_schema.holidays OWNER TO postgres;

--
-- Name: menus; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.menus (
    id uuid NOT NULL,
    name character varying(50) NOT NULL,
    url character varying(100),
    level character varying(2) NOT NULL,
    parent_id uuid,
    display_order integer NOT NULL
);


ALTER TABLE test_tenant_schema.menus OWNER TO postgres;

--
-- Name: parents; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.parents (
    id uuid NOT NULL,
    name character varying(100) NOT NULL,
    email character varying(100),
    phone character varying(15),
    occupation character varying(100),
    aadhar_number character varying(12),
    gender character varying(10),
    relation_to_student character varying(20),
    user_id uuid NOT NULL
);


ALTER TABLE test_tenant_schema.parents OWNER TO postgres;

--
-- Name: resource_permissions; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.resource_permissions (
    id uuid NOT NULL,
    role_id uuid NOT NULL,
    resource character varying(50) NOT NULL,
    action character varying(30) NOT NULL,
    is_granted boolean NOT NULL
);


ALTER TABLE test_tenant_schema.resource_permissions OWNER TO postgres;

--
-- Name: role_inheritance; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.role_inheritance (
    id uuid NOT NULL,
    tenant_role_id uuid NOT NULL,
    public_role_template_id integer NOT NULL,
    is_active boolean
);


ALTER TABLE test_tenant_schema.role_inheritance OWNER TO postgres;

--
-- Name: role_menu_permissions; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.role_menu_permissions (
    id uuid NOT NULL,
    role_id uuid NOT NULL,
    menu_id uuid NOT NULL,
    can_view boolean,
    can_edit boolean
);


ALTER TABLE test_tenant_schema.role_menu_permissions OWNER TO postgres;

--
-- Name: roles; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.roles (
    id uuid NOT NULL,
    name character varying(50) NOT NULL,
    description character varying(100),
    is_system_role boolean,
    is_custom_role boolean
);


ALTER TABLE test_tenant_schema.roles OWNER TO postgres;

--
-- Name: route_stops; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.route_stops (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    route_id uuid,
    name character varying NOT NULL,
    number integer,
    reaching_time time without time zone,
    fees integer,
    is_active boolean
);


ALTER TABLE test_tenant_schema.route_stops OWNER TO postgres;

--
-- Name: routes; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.routes (
    id uuid NOT NULL,
    route_name character varying NOT NULL,
    starting_stop character varying NOT NULL,
    ending_stop character varying NOT NULL,
    number_of_stops integer,
    route_type character varying,
    trip_type character varying,
    start_time time without time zone,
    end_time time without time zone,
    is_active boolean
);


ALTER TABLE test_tenant_schema.routes OWNER TO postgres;

--
-- Name: sections; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.sections (
    id uuid NOT NULL,
    name character varying(50) NOT NULL,
    description character varying(50),
    is_active boolean,
    class_id uuid NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE test_tenant_schema.sections OWNER TO postgres;

--
-- Name: slot_times; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.slot_times (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    section_id uuid NOT NULL,
    label character varying,
    start_time time without time zone NOT NULL,
    end_time time without time zone NOT NULL
);


ALTER TABLE test_tenant_schema.slot_times OWNER TO postgres;

--
-- Name: staff; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.staff (
    id uuid NOT NULL,
    first_name character varying(100) NOT NULL,
    last_name character varying(100),
    email character varying(100),
    phone character varying(15),
    gender cos360_main.genderenum,
    date_of_birth date,
    joining_date date NOT NULL,
    qualification character varying(100),
    experience_years integer,
    address character varying(255),
    designation_id uuid,
    department character varying(100),
    is_active boolean,
    user_id uuid NOT NULL
);


ALTER TABLE test_tenant_schema.staff OWNER TO postgres;

--
-- Name: staff_attendance; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.staff_attendance (
    id uuid NOT NULL,
    staff_id uuid NOT NULL,
    date date NOT NULL,
    status character varying(10) NOT NULL
);


ALTER TABLE test_tenant_schema.staff_attendance OWNER TO postgres;

--
-- Name: student_admissions; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.student_admissions (
    id uuid NOT NULL,
    student_id uuid NOT NULL,
    admission_number character varying(50),
    admission_date date NOT NULL,
    academic_year_id uuid,
    admitted_academic_year_id uuid,
    admitted_class_id uuid,
    admitted_section_id uuid,
    current_class_id uuid,
    current_section_id uuid,
    address_line1 character varying(255),
    address_line2 character varying(255),
    city character varying(100),
    state character varying(100),
    is_previous_school boolean,
    previous_school_name character varying(255),
    previous_class character varying(50),
    previous_school_remark character varying(100)
);


ALTER TABLE test_tenant_schema.student_admissions OWNER TO postgres;

--
-- Name: student_attendance; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.student_attendance (
    id uuid NOT NULL,
    student_id uuid NOT NULL,
    date date NOT NULL,
    status character varying(20) NOT NULL,
    remarks text
);


ALTER TABLE test_tenant_schema.student_attendance OWNER TO postgres;

--
-- Name: student_certificates; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.student_certificates (
    id uuid NOT NULL,
    student_id uuid NOT NULL,
    certificate_type_id uuid,
    issue_date date,
    file_path character varying,
    remarks character varying(255)
);


ALTER TABLE test_tenant_schema.student_certificates OWNER TO postgres;

--
-- Name: student_documents; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.student_documents (
    id uuid NOT NULL,
    student_id uuid NOT NULL,
    document_type character varying NOT NULL,
    file_path character varying NOT NULL,
    upload_date timestamp without time zone
);


ALTER TABLE test_tenant_schema.student_documents OWNER TO postgres;

--
-- Name: student_homework; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.student_homework (
    id uuid NOT NULL,
    student_id uuid NOT NULL,
    subject_id uuid,
    description text,
    due_date date,
    submission_status character varying(20)
);


ALTER TABLE test_tenant_schema.student_homework OWNER TO postgres;

--
-- Name: student_parent_links; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.student_parent_links (
    id uuid NOT NULL,
    student_id uuid,
    parent_id uuid
);


ALTER TABLE test_tenant_schema.student_parent_links OWNER TO postgres;

--
-- Name: student_transport_assignments; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.student_transport_assignments (
    id uuid NOT NULL,
    student_id uuid NOT NULL,
    trip_id uuid NOT NULL,
    stop_id uuid NOT NULL,
    fee_per_term double precision NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE test_tenant_schema.student_transport_assignments OWNER TO postgres;

--
-- Name: student_trips; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.student_trips (
    id uuid NOT NULL,
    trip_id uuid,
    student_id uuid,
    stop_id uuid,
    fee_term_id uuid,
    fee_per_term integer,
    is_active boolean
);


ALTER TABLE test_tenant_schema.student_trips OWNER TO postgres;

--
-- Name: students; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.students (
    id uuid NOT NULL,
    first_name character varying(100) NOT NULL,
    last_name character varying(100) NOT NULL,
    date_of_birth date NOT NULL,
    gender character varying(10),
    is_primary character varying(20),
    aadhar_number character varying(12),
    apaar_number character varying(12),
    caste character varying(100),
    sub_caste character varying(100),
    community character varying(100),
    nationality character varying(100),
    mother_tongue character varying(100),
    identification_marks character varying(100),
    user_id uuid NOT NULL
);


ALTER TABLE test_tenant_schema.students OWNER TO postgres;

--
-- Name: subject_categories; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.subject_categories (
    id uuid NOT NULL,
    name character varying(100) NOT NULL
);


ALTER TABLE test_tenant_schema.subject_categories OWNER TO postgres;

--
-- Name: subjects; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.subjects (
    id uuid NOT NULL,
    name character varying(50) NOT NULL,
    category_id uuid,
    is_active boolean,
    short_code character varying(10),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    academic_year_id uuid NOT NULL
);


ALTER TABLE test_tenant_schema.subjects OWNER TO postgres;

--
-- Name: timetable_slots; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.timetable_slots (
    id uuid NOT NULL,
    timetable_id uuid,
    day character varying NOT NULL,
    slot_time_id uuid,
    is_break boolean,
    break_label character varying
);


ALTER TABLE test_tenant_schema.timetable_slots OWNER TO postgres;

--
-- Name: timetable_subject_options; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.timetable_subject_options (
    id uuid NOT NULL,
    slot_id uuid NOT NULL,
    subject_id uuid
);


ALTER TABLE test_tenant_schema.timetable_subject_options OWNER TO postgres;

--
-- Name: timetables; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.timetables (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    section_id uuid NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE test_tenant_schema.timetables OWNER TO postgres;

--
-- Name: trips; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.trips (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    vehicle_id uuid,
    route_id uuid,
    driver_id uuid,
    trip_number integer
);


ALTER TABLE test_tenant_schema.trips OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.users (
    id uuid NOT NULL,
    username character varying(50) NOT NULL,
    email character varying(100),
    password_hash character varying(255) NOT NULL,
    is_active boolean,
    role_id uuid NOT NULL
);


ALTER TABLE test_tenant_schema.users OWNER TO postgres;

--
-- Name: vehicles; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.vehicles (
    id uuid NOT NULL,
    name character varying,
    registration_number character varying,
    vehicle_type character varying,
    last_inspected_date date,
    pollution_renewal_date date,
    is_active boolean
);


ALTER TABLE test_tenant_schema.vehicles OWNER TO postgres;

--
-- Data for Name: academic_years; Type: TABLE DATA; Schema: test_tenant_schema; Owner: postgres
--

COPY test_tenant_schema.academic_years (id, title, is_active, start_date, end_date, created_at, updated_at) FROM stdin;
0371fbc6-e3e8-4b41-9016-1153e5045eba	Test Academic Year 2024-25 20250908_213006	f	2024-04-01	2025-03-31	2025-09-08 21:30:06.806986	2025-09-08 21:37:25.573578
1f47ee96-3f51-40bc-b795-2ccd592f42b0	Test Academic Year 2024-25	f	2024-04-01	2025-03-31	2025-09-08 21:46:27.752449	2025-09-08 21:50:50.163098
cb25207d-753d-4aac-92f7-0cb2bc862584	Test Academic Year 2025-26 Raj	f	2025-04-01	2026-03-31	2025-09-08 21:50:50.163098	2025-09-08 21:51:13.160333
127e0439-06dc-46ac-a89a-fe291400f148	Test Academic Year 2026-27 Raj	f	2026-04-01	2027-03-31	2025-09-08 21:51:13.160333	2025-09-10 12:32:59.282934
68adf69b-573f-49fc-bdc9-1c3c084f9318	Test Academic Year 2025-2026	f	2025-04-01	2026-03-31	2025-09-10 12:32:59.282934	2025-09-10 12:34:33.213234
026f5d69-8dc5-4211-8411-861a14feef4e	Test Academic Year 2025-2026 9b24	f	2025-04-01	2026-03-31	2025-09-10 12:34:33.213234	2025-09-10 19:49:56.343057
2ac52312-be24-40ea-885e-c76c8e8fe5c8	Delete Test Year 2030-2031 55d5	f	2030-04-01	2031-03-31	2025-09-10 19:49:59.453601	2025-09-10 19:49:59.453601
23abbf92-c417-41a3-811d-d0b9edd183e7	Test Academic Year 2025-2026 20dd	f	2025-04-01	2026-03-31	2025-09-10 19:49:56.343057	2025-09-10 19:50:02.206262
7bb3b567-d08b-4cf7-9b6d-ff297ea13c60	Invalid Date Range 54ef4b24	f	2025-04-01	2024-03-31	2025-09-10 19:50:02.206262	2025-09-10 19:50:04.770512
49e1384b-ee78-4790-b05b-178354706522	Duplicate Test 2035-2036	f	2035-04-01	2036-03-31	2025-09-10 19:50:04.770512	2025-09-10 19:50:05.001766
a0d665e1-1415-4586-a505-2a681ecbbed0	Updated E2E Test Year 2045-2046 73d9	f	2045-04-01	2046-03-31	2025-09-10 19:50:05.001766	2025-09-10 19:50:05.071753
81ff31dc-a589-428a-a9b5-1f5483424190	Academic Year 2025-26	f	2025-04-01	2026-03-31	2025-09-10 20:03:25.441632	2025-09-10 20:07:00.926618
f1bcdd52-52d0-4ebb-8c24-9b336578cf07	Delete Test Year 2030-2031 4097	f	2030-04-01	2031-03-31	2025-09-10 20:07:03.736431	2025-09-10 20:07:03.736431
5311c404-ceb6-4cc6-8173-3f692c115abc	Test Academic Year 2025-2026 6db2	f	2025-04-01	2026-03-31	2025-09-10 20:07:00.926618	2025-09-10 20:07:03.846274
73e53601-1ae1-47f5-b4cf-c659778fa5e0	Invalid Date Range 6f30411f	f	2025-04-01	2024-03-31	2025-09-10 20:07:03.846274	2025-09-10 20:07:04.026021
2006ffa4-0cd8-4175-9510-42065fbbae80	Updated E2E Test Year 2045-2046 e6bd	f	2045-04-01	2046-03-31	2025-09-10 20:07:04.026021	2025-09-10 20:07:04.102197
14910a7c-07a5-407c-abcc-18b487d67ac1	Test Academic Year 2025-26	f	2025-04-01	2026-03-31	2025-09-08 21:37:25.573578	2025-09-08 21:46:27.752449
c8e1ea7d-f2e5-4b49-b515-f29fba63c890	Direct Test Academic Year 2024-25	f	2024-04-01	2025-03-31	2025-09-08 20:27:19.400134	2025-09-11 12:41:10.646318
fccbedb4-d00b-42e4-bf63-9d5b35294065	Test Schema Context Academic Year	t	2024-01-01	2024-12-31	2025-09-11 12:41:10.646318	2025-09-11 12:41:10.646318
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: test_tenant_schema; Owner: postgres
--

COPY test_tenant_schema.alembic_version (version_num) FROM stdin;
ea91fcd9d2f8
\.


--
-- Data for Name: certificate_types; Type: TABLE DATA; Schema: test_tenant_schema; Owner: postgres
--

COPY test_tenant_schema.certificate_types (id, name, description) FROM stdin;
d9d22605-0416-4f03-b4de-9bc6b38e22f5	Study Certificate	Certificate for academic purposes
1efb16a0-eb4f-4d8c-acec-20254c138036	Test Certificate d62c6e1f	Certificate for automated testing - 2025-09-10T06:56:55.014Z
421c594c-43d8-42b0-85fc-6ec26df3eb91	Updated Bonafide Certificate 1757487417006	Updated description 1757487417006
6c19c722-318a-4127-b9bd-09937b56447c	Test Certificate 8393b34b	Certificate for automated testing - 2025-09-10T06:57:40.655Z
0bec9cb5-39cc-440e-aeca-b1560f302ff9	Updated Duplicate Test 8550c4cf 1757487461467	Updated description 1757487461467
f857b827-bd00-481f-b51f-8529876245fe	Duplicate Test abe52ab5	Test duplicate name handling
\.


--
-- Data for Name: class_subject_mappings; Type: TABLE DATA; Schema: test_tenant_schema; Owner: postgres
--

COPY test_tenant_schema.class_subject_mappings (id, class_id, subject_id, is_active, created_at, updated_at, academic_year_id, exclude_marks, "order") FROM stdin;
\.


--
-- Data for Name: classes; Type: TABLE DATA; Schema: test_tenant_schema; Owner: postgres
--

COPY test_tenant_schema.classes (id, name, description, is_active, short_code, created_at, updated_at, academic_year_id) FROM stdin;
\.


--
-- Data for Name: designations; Type: TABLE DATA; Schema: test_tenant_schema; Owner: postgres
--

COPY test_tenant_schema.designations (id, title) FROM stdin;
f27a8a78-2af6-4034-adc3-a4896c1ffc29	Updated Test Designation d959ddc5 1757488330897
ec47f4a6-1a9d-4b6f-8b13-baafa2a9473f	Test Designation 6ca309ea
29656cef-f780-4ad1-8039-2fcb89ae1148	Updated Duplicate Test 4b630a9f 1757488360024
b7aea193-a7ed-4197-9623-5fe8f9775427	Duplicate Test 658e7547
\.


--
-- Data for Name: expense_attachments; Type: TABLE DATA; Schema: test_tenant_schema; Owner: postgres
--

COPY test_tenant_schema.expense_attachments (id, transaction_id, original_filename, stored_filename, file_path, file_size, mime_type, file_extension, file_hash_sha256, virus_scan_status, virus_scan_result, virus_scanned_at, is_public, is_encrypted, encryption_key_id, document_type, is_verified, verified_by_user_id, verified_at, verification_notes, retention_period_months, is_archived, archived_at, can_be_deleted, department_id, uploaded_by_user_id, uploaded_by_role, uploaded_at, last_accessed_at, access_count, updated_at, org_id) FROM stdin;
\.


--
-- Data for Name: expense_audit_logs; Type: TABLE DATA; Schema: test_tenant_schema; Owner: postgres
--

COPY test_tenant_schema.expense_audit_logs (id, transaction_id, action, action_category, field_name, old_value, new_value, full_record_before, full_record_after, action_reason, action_notes, request_ip_address, request_user_agent, request_session_id, api_endpoint, http_method, request_id, workflow_stage, compliance_flags, department_id, actor_user_id, actor_role, actor_username, created_at, org_id) FROM stdin;
\.


--
-- Data for Name: expense_categories; Type: TABLE DATA; Schema: test_tenant_schema; Owner: postgres
--

COPY test_tenant_schema.expense_categories (id, name, description, is_active, created_at, updated_at, org_id) FROM stdin;
\.


--
-- Data for Name: expense_settings; Type: TABLE DATA; Schema: test_tenant_schema; Owner: postgres
--

COPY test_tenant_schema.expense_settings (id, setting_key, setting_name, setting_description, setting_category, string_value, numeric_value, integer_value, boolean_value, "json_value", default_value, is_system_setting, is_user_configurable, validation_rules, allowed_values, requires_approval, approval_threshold, department_id, applies_to_all_departments, is_audit_required, is_sensitive, compliance_level, version, is_active, effective_from, effective_until, created_by_user_id, created_by_role, last_modified_by_user_id, last_modified_by_role, created_at, updated_at, org_id) FROM stdin;
\.


--
-- Data for Name: expense_transaction_items; Type: TABLE DATA; Schema: test_tenant_schema; Owner: postgres
--

COPY test_tenant_schema.expense_transaction_items (id, transaction_id, item_name, item_description, unit_price, quantity, total_price, item_category, tax_rate, tax_amount, discount_rate, discount_amount, final_amount, vendor_item_code, vendor_item_reference, created_by_user_id, created_by_role, created_at, updated_at, org_id) FROM stdin;
\.


--
-- Data for Name: expense_transactions; Type: TABLE DATA; Schema: test_tenant_schema; Owner: postgres
--

COPY test_tenant_schema.expense_transactions (id, expense_type_id, amount, transaction_date, description, reference_number, idempotency_key, payment_method, vendor_name, status, requires_approval, requires_approval_override, approved_by_user_id, approved_by_role, approved_at, approval_comment, department_id, version, created_by_user_id, created_by_role, created_at, updated_at, org_id) FROM stdin;
\.


--
-- Data for Name: expense_types; Type: TABLE DATA; Schema: test_tenant_schema; Owner: postgres
--

COPY test_tenant_schema.expense_types (id, name, category_id, description, is_active, created_at, updated_at, org_id) FROM stdin;
\.


--
-- Data for Name: fee_categories; Type: TABLE DATA; Schema: test_tenant_schema; Owner: postgres
--

COPY test_tenant_schema.fee_categories (id, category_name, category_status, academic_year_id, created_at, updated_at) FROM stdin;
e85ce591-b046-4819-ba72-85489bae6af3	Updated Updated Test Fee Category 09e4d333 1757487779709 1757487946981	active	68adf69b-573f-49fc-bdc9-1c3c084f9318	2025-09-10 12:32:59.390678	2025-09-10 12:35:46.992981
e949c638-0523-4375-a7f6-e365d2fbc22b	Test Fee Category 410b9cec	active	026f5d69-8dc5-4211-8411-861a14feef4e	2025-09-10 12:36:49.554043	2025-09-10 12:36:49.554043
a36b0f3c-4677-472b-95c9-5ccbb66bc6d8	Updated Test Fee Category d665c269 1757488009897	active	026f5d69-8dc5-4211-8411-861a14feef4e	2025-09-10 12:35:43.941709	2025-09-10 12:36:49.904931
\.


--
-- Data for Name: fee_class_map_term_amounts; Type: TABLE DATA; Schema: test_tenant_schema; Owner: postgres
--

COPY test_tenant_schema.fee_class_map_term_amounts (id, fee_class_mapping_id, term_id, term_amount, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: fee_class_mappings; Type: TABLE DATA; Schema: test_tenant_schema; Owner: postgres
--

COPY test_tenant_schema.fee_class_mappings (id, class_id, fee_type_id, total_fee, academic_year_id, all_by_default, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: fee_receipts; Type: TABLE DATA; Schema: test_tenant_schema; Owner: postgres
--

COPY test_tenant_schema.fee_receipts (id, receipt_number, fee_transaction_id, student_name, student_admission_num, class_section, academic_year, content_hash, pdf_file_path, is_reprinted, reprint_count, generated_by_user_id, remarks, generated_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: fee_refunds; Type: TABLE DATA; Schema: test_tenant_schema; Owner: postgres
--

COPY test_tenant_schema.fee_refunds (id, refund_number, fee_transaction_id, student_id, student_admission_num, academic_year_id, refund_amount, refund_reason, detailed_reason, status, requested_by_user_id, approved_by_user_id, processed_by_user_id, refund_method, refund_reference, approval_remarks, processing_remarks, requested_date, approved_date, processed_date, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: fee_term_dates; Type: TABLE DATA; Schema: test_tenant_schema; Owner: postgres
--

COPY test_tenant_schema.fee_term_dates (id, term_id, fee_term_date, created_at, updated_at) FROM stdin;
49fe9035-8954-41a3-80a4-9be1c6c29489	a1234567-89ab-cdef-0123-456789abcdef	2024-04-15	2025-09-09 14:13:33.617853	2025-09-09 14:13:33.617853
3658f94a-91bd-495d-aacc-3ab01a0c9c08	a1234567-89ab-cdef-0123-456789abcdef	2024-07-15	2025-09-09 14:13:33.617853	2025-09-09 14:13:33.617853
85b72230-0493-427e-ad7f-e3e61f3fa39c	a1234567-89ab-cdef-0123-456789abcdef	2024-10-15	2025-09-09 14:13:33.617853	2025-09-09 14:13:33.617853
1c382f7e-73de-4d09-a3cc-6d1ae5c7be86	a1234567-89ab-cdef-0123-456789abcdef	2025-01-15	2025-09-09 14:13:33.617853	2025-09-09 14:13:33.617853
a6470a98-4c7f-4872-a208-a90f35b6b8a7	b1234567-89ab-cdef-0123-456789abcdef	2024-04-01	2025-09-09 14:13:33.617853	2025-09-09 14:13:33.617853
f1914b5d-124b-4e01-bfc2-f882d73d7602	b1234567-89ab-cdef-0123-456789abcdef	2024-05-01	2025-09-09 14:13:33.617853	2025-09-09 14:13:33.617853
5d5e82d6-82e5-404e-8254-65192d8f8d2c	b1234567-89ab-cdef-0123-456789abcdef	2024-06-01	2025-09-09 14:13:33.617853	2025-09-09 14:13:33.617853
56985061-99c2-44b5-88ad-6654f209fc5c	ce4bcade-8620-4d6e-b0c8-fc493cfcc4b0	2024-04-01	2025-09-10 13:03:20.287172	2025-09-10 13:03:20.287172
807741be-d26f-43cf-98c2-ec52dd0023c8	ce4bcade-8620-4d6e-b0c8-fc493cfcc4b0	2024-07-01	2025-09-10 13:03:20.287172	2025-09-10 13:03:20.287172
854afb87-628e-432a-9c87-5576999bb754	ce4bcade-8620-4d6e-b0c8-fc493cfcc4b0	2024-10-01	2025-09-10 13:03:20.287172	2025-09-10 13:03:20.287172
72a3b0be-8e54-43b1-b7d6-8ef3a1dac2bb	ce4bcade-8620-4d6e-b0c8-fc493cfcc4b0	2025-01-01	2025-09-10 13:03:20.287172	2025-09-10 13:03:20.287172
b317558d-ca75-457b-9774-e81fef453453	07663560-f46d-4c3a-b0cc-5877135cbfd7	2024-04-01	2025-09-10 13:12:30.813284	2025-09-10 13:12:30.813284
d2cbb01c-b54c-4c0c-97a6-c15777c36afb	07663560-f46d-4c3a-b0cc-5877135cbfd7	2024-10-01	2025-09-10 13:12:30.813284	2025-09-10 13:12:30.813284
ed80cf0b-c8d2-480a-aa91-2d689a53e89d	db439d9e-4873-4ff3-a95e-9c886e2fea82	2024-04-01	2025-09-10 13:15:36.192862	2025-09-10 13:15:36.192862
ad960e66-5bcd-4378-acc4-e9ce706e3ec3	db439d9e-4873-4ff3-a95e-9c886e2fea82	2024-08-01	2025-09-10 13:15:36.192862	2025-09-10 13:15:36.192862
73d8159f-04cb-44e6-8ae9-bd06828e329c	db439d9e-4873-4ff3-a95e-9c886e2fea82	2024-12-01	2025-09-10 13:15:36.192862	2025-09-10 13:15:36.192862
\.


--
-- Data for Name: fee_terms; Type: TABLE DATA; Schema: test_tenant_schema; Owner: postgres
--

COPY test_tenant_schema.fee_terms (id, term_name, term_status, number_of_terms, academic_year_id, created_at, updated_at) FROM stdin;
a1234567-89ab-cdef-0123-456789abcdef	Quarterly Payment	active	4	1f47ee96-3f51-40bc-b795-2ccd592f42b0	2025-09-09 14:13:33.617853	2025-09-09 14:13:33.617853
b1234567-89ab-cdef-0123-456789abcdef	Monthly Payment	active	12	1f47ee96-3f51-40bc-b795-2ccd592f42b0	2025-09-09 14:13:33.617853	2025-09-09 14:13:33.617853
f20dcd37-dda8-4965-b749-82f5defcf8f8	Invalid Terms Count 2c9b57c6	active	0	026f5d69-8dc5-4211-8411-861a14feef4e	2025-09-10 12:53:33.223742	2025-09-10 12:53:33.223742
1b9f9192-0b0a-4a39-a86d-74e3af03a360	Invalid Terms Count 50e920fb	active	0	026f5d69-8dc5-4211-8411-861a14feef4e	2025-09-10 12:54:47.435356	2025-09-10 12:54:47.435356
959c6799-ac0c-4f30-b5f0-4d97b1ca3b69	Invalid Terms Count 9979d1e5	active	0	026f5d69-8dc5-4211-8411-861a14feef4e	2025-09-10 12:55:19.466713	2025-09-10 12:55:19.466713
ce4bcade-8620-4d6e-b0c8-fc493cfcc4b0	Updated Q1 2024 Test	active	4	026f5d69-8dc5-4211-8411-861a14feef4e	2025-09-10 13:03:20.287172	2025-09-10 13:04:15.693493
07663560-f46d-4c3a-b0cc-5877135cbfd7	Updated Test Fixed Create	active	2	026f5d69-8dc5-4211-8411-861a14feef4e	2025-09-10 13:12:30.813284	2025-09-10 13:14:23.488069
db439d9e-4873-4ff3-a95e-9c886e2fea82	Final Test Create	active	3	026f5d69-8dc5-4211-8411-861a14feef4e	2025-09-10 13:15:36.192862	2025-09-10 13:15:36.192862
\.


--
-- Data for Name: fee_transaction_items; Type: TABLE DATA; Schema: test_tenant_schema; Owner: postgres
--

COPY test_tenant_schema.fee_transaction_items (id, fee_transaction_id, fee_type_id, fee_term_id, amount_due, amount_paid, description, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: fee_transactions; Type: TABLE DATA; Schema: test_tenant_schema; Owner: postgres
--

COPY test_tenant_schema.fee_transactions (id, transaction_number, student_id, student_admission_num, academic_year_id, total_amount, payment_method, status, upi_reference, upi_app_name, cheque_number, cheque_date, cheque_bank, cheque_status, bank_reference, bank_name, collected_by_user_id, approved_by_user_id, receipt_generated, receipt_hash, remarks, transaction_date, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: fee_types; Type: TABLE DATA; Schema: test_tenant_schema; Owner: postgres
--

COPY test_tenant_schema.fee_types (id, type_name, fee_category_id, fee_status, fee_term_id, academic_year_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: holidays; Type: TABLE DATA; Schema: test_tenant_schema; Owner: postgres
--

COPY test_tenant_schema.holidays (id, name, description, start_date, end_date, is_active, created_at, updated_at, academic_year_id) FROM stdin;
\.


--
-- Data for Name: menus; Type: TABLE DATA; Schema: test_tenant_schema; Owner: postgres
--

COPY test_tenant_schema.menus (id, name, url, level, parent_id, display_order) FROM stdin;
8cb23322-0e9d-406f-9908-73bb6a82550f	Dashboard	/dashboard	L0	\N	0
dfd80d48-67fd-4a80-aeec-5e51a5348d9d	Masters	/masters	L0	\N	1
fbc4bfb1-42eb-4816-b514-52fc2a98611e	Students	/students	L0	\N	2
6fb61634-9000-4165-9ad7-435b9d71bc24	Fee Management	/fees	L0	\N	3
b415224d-8058-40f7-8107-d15e7ef69dcc	Transport	/transport	L0	\N	4
8792498d-df9a-4a95-84a9-aa333e4e6844	Reports	/reports	L0	\N	5
e0ad58c0-6c72-4930-9c24-f951ef0b42b5	Administration	/admin	L0	\N	6
fead4d8f-46fc-4b60-9cbd-88c3e1fc225a	Academic Years	/masters/academic-years	L1	\N	7
64b8a80a-6d7a-4b81-a161-d8374ccd79ec	Classes	/masters/classes	L1	\N	8
3c2ea797-32ae-49db-88de-83fcac59bbb2	Sections	/masters/sections	L1	\N	9
bb2f9ca7-80fc-44c4-957e-ffa84dc1c181	Staff Management	/masters/staff	L1	\N	10
a36e50ed-9547-4b79-bf3e-6090294d03a3	Staff Attendance	/masters/staff-attendance	L1	\N	11
92446059-113a-4961-9c1c-ce8e29a2880f	Designations	/masters/designations	L1	\N	12
c2de843f-517d-4370-a670-3a44b857a777	Subjects	/masters/subjects	L1	\N	13
6e230039-387d-441a-8e9e-01bb0416a6eb	Subject Categories	/masters/subject-categories	L1	\N	14
132299aa-5c3a-4be6-8260-9d6e6fa630c5	Class Subject Mappings	/masters/class-subject-mappings	L1	\N	15
562075e7-9d0c-47fb-8cdf-ed2075637c51	Holiday Management	/masters/holiday-management	L1	\N	16
7857839b-1fa6-48cd-b4ff-19b83ef6d2cc	Holidays	/masters/holidays	L1	\N	17
71b7ce7e-ea13-4d2e-8509-70523f63b4be	Parents	/masters/parents	L1	\N	18
6111b863-e6da-444d-a6a1-31c03c7b2cee	Timetable Management	/masters/timetable-management	L1	\N	19
cf4c4594-eb27-4863-964d-56a7ebd3997a	Student Admissions	/students/admissions	L1	\N	20
3cc15a0a-800c-4cd0-8986-3273da640a78	Student Attendance	/students/attendance	L1	\N	21
9772e642-0600-4242-aa7f-d79eee8959eb	Student Documents	/students/documents	L1	\N	22
4df6e384-bb0d-45f7-b035-8946e64454c0	Student Certificates	/students/certificates	L1	\N	23
59b104a7-c8fb-4567-9cd2-a157e97b5018	Certificate Types	/students/certificate-types	L1	\N	24
57809a83-add0-48ac-894a-b6d2899863f1	Student Transport	/students/transport	L1	\N	25
766afdef-05e6-4195-b103-bd8198a33cfe	Fee Categories	/fees/categories	L1	\N	26
694fb8ea-8aa4-444b-a551-550759ca79a9	Fee Types	/fees/types	L1	\N	27
2092884a-4fc9-40cd-bee8-99cc3c5a0212	Fee Terms	/fees/terms	L1	\N	28
28f266c8-6096-4ec2-ae92-607647570bd7	Fee Class Mappings	/fees/class-mappings	L1	\N	29
4f804896-c88a-49b2-b4de-c6de3f1558c3	Fee Student Mappings	/fees/student-mappings	L1	\N	30
bf6e49fb-ecf1-4ce9-8eaf-87a572916bf9	Fee Term Amounts	/fees/term-amounts	L1	\N	31
46760949-79fc-49f7-93d0-9bdac2b50f07	Fee Collection	/fees/transactions	L1	\N	32
ecc64393-c892-4721-b630-47c199274609	Fee Receipts	/fees/receipts	L1	\N	33
d7f5e4d5-63e0-42a1-aa44-1f22b6ea5cad	Fee Refunds	/fees/refunds	L1	\N	34
177774ab-89f6-405c-9ab9-20fd1fdfd27a	Routes	/transport/routes	L1	\N	35
59a7e53b-aa6d-46c7-855d-d07004c4c287	Route Stops	/transport/route-stops	L1	\N	36
7dc5ae2c-17d5-42a6-a5bc-88b88ec3760c	Vehicles	/transport/vehicles	L1	\N	37
20b5f5c5-50ee-4195-9f9a-09b6e6ac5ff5	Transport Routes	/transport/transport-routes	L1	\N	38
09fd0888-5569-40b9-969c-421bf9a47833	Transport Trips	/transport/trips	L1	\N	39
5687ca06-e8b4-488f-966c-290f8b4ac824	Student Reports	/reports/students	L1	\N	40
e7395635-aa1b-4c41-b929-1be78e989e6f	Fee Reports	/reports/fees	L1	\N	41
89a39c8f-f0a3-4ec7-9f1a-cb3f6572f4a4	Staff Reports	/reports/staff	L1	\N	42
729a3689-8e0c-490a-a574-cd4a19f48530	Transport Reports	/reports/transport	L1	\N	43
83216c1d-fa8d-41db-881d-3d238bef4422	Academic Reports	/reports/academic	L1	\N	44
29204691-4ea0-478e-84bd-5c6e4a349aa5	User Management	/admin/users	L1	\N	45
37cfe65d-dcf9-49c9-9e6b-1d64483b1564	Role Management	/admin/roles	L1	\N	46
9aa19eca-1b01-448f-8fe3-b29ff7f2efe0	Permission Management	/admin/permissions	L1	\N	47
9e27304b-f4a9-4d13-8a6c-784354c33a57	Menu Management	/admin/menus	L1	\N	48
\.


--
-- Data for Name: parents; Type: TABLE DATA; Schema: test_tenant_schema; Owner: postgres
--

COPY test_tenant_schema.parents (id, name, email, phone, occupation, aadhar_number, gender, relation_to_student, user_id) FROM stdin;
\.


--
-- Data for Name: resource_permissions; Type: TABLE DATA; Schema: test_tenant_schema; Owner: postgres
--

COPY test_tenant_schema.resource_permissions (id, role_id, resource, action, is_granted) FROM stdin;
4b16368e-4d93-4003-b9ac-41cd9f83e12a	2fe97570-0740-44c5-911f-9826e0258a9b	routes	create	t
8159db94-7cb2-45d9-9e15-4f11e887787f	2fe97570-0740-44c5-911f-9826e0258a9b	routes	read	t
75feb278-aef7-4d3e-aaf7-5c3491da352f	2fe97570-0740-44c5-911f-9826e0258a9b	routes	update	t
eb317e51-2a30-4c65-9f21-ce8b97d31002	2fe97570-0740-44c5-911f-9826e0258a9b	routes	delete	t
7f267bf0-c18a-4644-80ce-1721f5a5bd77	2fe97570-0740-44c5-911f-9826e0258a9b	routes	list	t
f455b84e-2c7e-40be-a2d8-e1b9a4fb8587	2fe97570-0740-44c5-911f-9826e0258a9b	vehicles	create	t
30f5664b-2b25-45cb-9f05-409f8b66ab18	2fe97570-0740-44c5-911f-9826e0258a9b	vehicles	read	t
60aa3e9e-5ab2-4f0a-8617-abb747aaa6a4	2fe97570-0740-44c5-911f-9826e0258a9b	vehicles	update	t
74224594-961a-42ac-bc8c-9c9c2aadf4a1	2fe97570-0740-44c5-911f-9826e0258a9b	vehicles	delete	t
e46fad2a-b372-4cec-aa46-7dda684941bb	2fe97570-0740-44c5-911f-9826e0258a9b	vehicles	list	t
7a034477-8502-4137-ab1f-83bbef6ac5aa	2fe97570-0740-44c5-911f-9826e0258a9b	class_subject_mappings	create	t
e66e8a9f-a81a-4051-bdca-180fc489602a	2fe97570-0740-44c5-911f-9826e0258a9b	class_subject_mappings	read	t
2ce60d14-3510-4ec1-bdcf-ba38bb1539eb	2fe97570-0740-44c5-911f-9826e0258a9b	class_subject_mappings	update	t
be1f1285-ec0f-4442-86d9-6864f81fbe4c	2fe97570-0740-44c5-911f-9826e0258a9b	class_subject_mappings	delete	t
7d2728ae-c1f8-4545-b050-a65d1ee964f5	2fe97570-0740-44c5-911f-9826e0258a9b	class_subject_mappings	list	t
c79acbce-13a8-4c68-a406-39c69a500340	2fe97570-0740-44c5-911f-9826e0258a9b	certificate_types	create	t
f2d1b31f-1a07-4016-adad-149a30770a3e	2fe97570-0740-44c5-911f-9826e0258a9b	certificate_types	read	t
900b63c2-206a-40d8-9c0f-7146f806b45b	2fe97570-0740-44c5-911f-9826e0258a9b	certificate_types	update	t
d03af2d0-eba4-4a3a-9e2f-3e2684c3fccc	2fe97570-0740-44c5-911f-9826e0258a9b	certificate_types	delete	t
0947fe87-5c7c-4454-8a85-4b96e334ddc3	2fe97570-0740-44c5-911f-9826e0258a9b	certificate_types	list	t
79309073-e049-4859-9ab2-05aca8f28364	2fe97570-0740-44c5-911f-9826e0258a9b	designations	create	t
fe2aa2cb-3a6a-4d3a-b51b-ee934a220a6f	2fe97570-0740-44c5-911f-9826e0258a9b	designations	read	t
6c52b8e0-5df6-4ca4-84f5-acdfd67ab086	2fe97570-0740-44c5-911f-9826e0258a9b	designations	update	t
4b3cd428-624c-45f8-8d3a-81348acafc20	2fe97570-0740-44c5-911f-9826e0258a9b	designations	delete	t
358a0490-4af5-4847-9399-ef4658c05e41	2fe97570-0740-44c5-911f-9826e0258a9b	designations	list	t
e4cd7eec-271f-47ae-9125-8c54578f1317	2fe97570-0740-44c5-911f-9826e0258a9b	classes	create	t
03b25e63-562a-49b7-8864-e36f4c1faa3b	2fe97570-0740-44c5-911f-9826e0258a9b	classes	read	t
4200e506-457a-4640-9fd1-fa39c26cddd2	2fe97570-0740-44c5-911f-9826e0258a9b	classes	update	t
4fcd09fc-0863-4ead-9e84-a083d6097823	2fe97570-0740-44c5-911f-9826e0258a9b	classes	delete	t
6d5c4c4d-3cb7-482c-82ce-67da316b6aaf	2fe97570-0740-44c5-911f-9826e0258a9b	classes	list	t
f5768a73-1e00-441e-96fd-1c5a646271c4	2fe97570-0740-44c5-911f-9826e0258a9b	staff	create	t
3e03a4e4-65e9-4008-85d2-77cade0a6b23	2fe97570-0740-44c5-911f-9826e0258a9b	staff	read	t
522acf28-3a12-4516-824d-ae0989f88f0a	2fe97570-0740-44c5-911f-9826e0258a9b	staff	update	t
a5c3b688-c7a3-4926-9aa2-136a55d40180	2fe97570-0740-44c5-911f-9826e0258a9b	staff	delete	t
03203d00-69ba-415f-b9bc-928f049639c5	2fe97570-0740-44c5-911f-9826e0258a9b	staff	list	t
22ebf4c5-e4b6-4e14-b510-f542bfea1440	2fe97570-0740-44c5-911f-9826e0258a9b	staff_attendance	create	t
dfb16f2e-4e91-4b37-8a43-61ee95b2bc94	2fe97570-0740-44c5-911f-9826e0258a9b	staff_attendance	read	t
9c3c0c65-d00f-4329-ad11-697f3ae96879	2fe97570-0740-44c5-911f-9826e0258a9b	staff_attendance	update	t
a486d4de-1612-4a1a-99d2-814bb97027a8	2fe97570-0740-44c5-911f-9826e0258a9b	staff_attendance	delete	t
541deff3-8f96-43dd-8444-9f271bcdbe39	2fe97570-0740-44c5-911f-9826e0258a9b	staff_attendance	list	t
cb1b899c-098f-444d-b2f3-b47b6467b8c8	2fe97570-0740-44c5-911f-9826e0258a9b	academic_years	create	t
46e49b52-4536-46dd-87f1-dfa042caadd4	2fe97570-0740-44c5-911f-9826e0258a9b	academic_years	read	t
881cf124-3dd1-453e-bb62-a070f7647d2b	2fe97570-0740-44c5-911f-9826e0258a9b	academic_years	update	t
a5c8e85c-fd9e-4110-9b23-a5ea3afb02b4	2fe97570-0740-44c5-911f-9826e0258a9b	academic_years	delete	t
315f4251-2bd2-4bed-888d-d4a9fdd191a0	2fe97570-0740-44c5-911f-9826e0258a9b	academic_years	list	t
9ac6b9cf-49b1-4363-b3e3-c02cf9af8f91	2fe97570-0740-44c5-911f-9826e0258a9b	sections	create	t
730f9b3c-5ca1-4a1b-be8a-a232f805dba8	2fe97570-0740-44c5-911f-9826e0258a9b	sections	read	t
3e44b590-2ee7-4afe-9351-f2a975fe186e	2fe97570-0740-44c5-911f-9826e0258a9b	sections	update	t
f755a969-fea7-4e33-807f-af3e442de2f1	2fe97570-0740-44c5-911f-9826e0258a9b	sections	delete	t
587e533f-7518-4aff-a19c-e9652a93e1e1	2fe97570-0740-44c5-911f-9826e0258a9b	sections	list	t
11327c5c-8171-4049-b3f5-b0e88ed63e54	2fe97570-0740-44c5-911f-9826e0258a9b	subjects	create	t
b5f21a4e-4148-4282-acae-84499743af50	2fe97570-0740-44c5-911f-9826e0258a9b	subjects	read	t
b658a677-5735-48f3-8161-c623007534ff	2fe97570-0740-44c5-911f-9826e0258a9b	subjects	update	t
b3afc847-cb7a-455e-ad8e-3420caa39cb1	2fe97570-0740-44c5-911f-9826e0258a9b	subjects	delete	t
bf5c67a3-dc89-4eed-93a5-edcf4ccd6ad4	2fe97570-0740-44c5-911f-9826e0258a9b	subjects	list	t
2872af0f-5da9-4f84-ad80-75c1ce3002f9	2fe97570-0740-44c5-911f-9826e0258a9b	subject_categories	create	t
2caee492-997e-436c-8c32-415400c285d2	2fe97570-0740-44c5-911f-9826e0258a9b	subject_categories	read	t
49c07e03-fbb7-42d1-bf0d-8041a25b38a6	2fe97570-0740-44c5-911f-9826e0258a9b	subject_categories	update	t
2dc7fca7-b67a-45ec-b086-d0e8227b5d91	2fe97570-0740-44c5-911f-9826e0258a9b	subject_categories	delete	t
beaa3880-7ba7-4370-8908-ae0668bfafd9	2fe97570-0740-44c5-911f-9826e0258a9b	subject_categories	list	t
0ac03003-9d8b-4384-9701-feef61a013ea	2fe97570-0740-44c5-911f-9826e0258a9b	fee_categories	create	t
37a98af0-d3a7-4798-91bc-41a3c6b0f4e5	2fe97570-0740-44c5-911f-9826e0258a9b	fee_categories	read	t
fea7c28c-4e11-4182-9f32-44b7b9100850	2fe97570-0740-44c5-911f-9826e0258a9b	fee_categories	update	t
cea06757-2cd3-4ffd-9922-5453af3c36e7	2fe97570-0740-44c5-911f-9826e0258a9b	fee_categories	delete	t
3d0975d9-e0ed-4b1e-867a-45ce40dc2a74	2fe97570-0740-44c5-911f-9826e0258a9b	fee_categories	list	t
e6ae6f0e-d286-4cc9-a0b4-e710a5377212	2fe97570-0740-44c5-911f-9826e0258a9b	fee_types	create	t
6ff1805d-d832-4cbf-a08e-79181a5bb63a	2fe97570-0740-44c5-911f-9826e0258a9b	fee_types	read	t
0a2797f9-125f-4cd4-9bad-93acf7390bde	2fe97570-0740-44c5-911f-9826e0258a9b	fee_types	update	t
c24c78e8-6ff6-48eb-b2e9-eabfed54895a	2fe97570-0740-44c5-911f-9826e0258a9b	fee_types	delete	t
0ba81974-5e98-425f-bde1-3c7c7a358cd7	2fe97570-0740-44c5-911f-9826e0258a9b	fee_types	list	t
9dd262a1-13f5-46ef-abf6-10274bd840bb	2fe97570-0740-44c5-911f-9826e0258a9b	fee_terms	create	t
394fc9a4-5639-444a-bd08-e20b3e68e80f	2fe97570-0740-44c5-911f-9826e0258a9b	fee_terms	read	t
7aef8eb5-8922-44e8-8e11-b4115b355e04	2fe97570-0740-44c5-911f-9826e0258a9b	fee_terms	update	t
340ba666-fb3a-407e-a108-96eb92cc57d2	2fe97570-0740-44c5-911f-9826e0258a9b	fee_terms	delete	t
01d05380-711f-41ef-95ba-925e70036fa0	2fe97570-0740-44c5-911f-9826e0258a9b	fee_terms	list	t
b3252dcc-03e0-456d-9906-aa6c69515ef6	2fe97570-0740-44c5-911f-9826e0258a9b	fee_class_mappings	create	t
c0e8b313-017b-44cf-b08f-59ea153df791	2fe97570-0740-44c5-911f-9826e0258a9b	fee_class_mappings	read	t
a6e65a00-1abf-4053-901f-a85edf1f4cc6	2fe97570-0740-44c5-911f-9826e0258a9b	fee_class_mappings	update	t
784b7a03-7c8a-489d-8793-48f41c7d3d71	2fe97570-0740-44c5-911f-9826e0258a9b	fee_class_mappings	delete	t
2d353937-41d1-474c-80c0-97653fc8f44d	2fe97570-0740-44c5-911f-9826e0258a9b	fee_class_mappings	list	t
5e2467e1-980f-4430-835f-f0b7dc5a0019	2fe97570-0740-44c5-911f-9826e0258a9b	fee_student_mappings	create	t
e19d3574-1683-4e3b-85bd-f92e5dd27fea	2fe97570-0740-44c5-911f-9826e0258a9b	fee_student_mappings	read	t
03408734-f6a0-4b4e-8c3b-34bc553d7e85	2fe97570-0740-44c5-911f-9826e0258a9b	fee_student_mappings	update	t
b7aeb51e-7645-4464-a3ae-5fcdd9dee868	2fe97570-0740-44c5-911f-9826e0258a9b	fee_student_mappings	delete	t
56e65ff4-a09b-4077-8402-0c1c48b7bfa4	2fe97570-0740-44c5-911f-9826e0258a9b	fee_student_mappings	list	t
c5c8c71e-37a1-4af2-aecb-19c6d144286d	2fe97570-0740-44c5-911f-9826e0258a9b	fee_term_amounts	create	t
5b2f10a2-992e-4835-83ad-5ded42dd0d4d	2fe97570-0740-44c5-911f-9826e0258a9b	fee_term_amounts	read	t
3c900231-5119-4b5e-abed-af8467a50103	2fe97570-0740-44c5-911f-9826e0258a9b	fee_term_amounts	update	t
4d3fe920-7af1-4fe8-8dfb-3afa44c969e8	2fe97570-0740-44c5-911f-9826e0258a9b	fee_term_amounts	delete	t
703bfe63-af13-4e26-8ee2-81624d7bac5f	2fe97570-0740-44c5-911f-9826e0258a9b	fee_term_amounts	list	t
d1020837-e327-46ea-af5d-81a2d2831220	2fe97570-0740-44c5-911f-9826e0258a9b	student_admissions	create	t
ca686fe5-f394-48fd-bac2-9654cceb9e9d	2fe97570-0740-44c5-911f-9826e0258a9b	student_admissions	read	t
4b0a8bec-6647-4b11-b4ee-ebd8e56319e4	2fe97570-0740-44c5-911f-9826e0258a9b	student_admissions	update	t
689a5f30-344e-48d7-a10f-a4f6179f701e	2fe97570-0740-44c5-911f-9826e0258a9b	student_admissions	delete	t
ed5714d2-2b82-44d2-8968-4a5cad77b404	2fe97570-0740-44c5-911f-9826e0258a9b	student_admissions	list	t
545d1443-f5dd-4ca3-beda-890fd480862f	2fe97570-0740-44c5-911f-9826e0258a9b	student_attendance	create	t
a7d484ed-5a93-4ff0-82f1-278016c5337a	2fe97570-0740-44c5-911f-9826e0258a9b	student_attendance	read	t
00f6e43c-bf74-4b47-ad28-0acfa3c4f002	2fe97570-0740-44c5-911f-9826e0258a9b	student_attendance	update	t
6f25a0a0-88d6-47d0-8c32-97eff0aed391	2fe97570-0740-44c5-911f-9826e0258a9b	student_attendance	delete	t
4cc3e3c9-e660-4a82-9dc0-f66199621d83	2fe97570-0740-44c5-911f-9826e0258a9b	student_attendance	list	t
73152855-76ed-4e64-a1d3-727b7f58b07e	2fe97570-0740-44c5-911f-9826e0258a9b	student_certificates	create	t
cf82c37c-805b-4798-8525-86fd751ce29c	2fe97570-0740-44c5-911f-9826e0258a9b	student_certificates	read	t
abf9ca85-aaf3-46a2-ad84-bbb73d205751	2fe97570-0740-44c5-911f-9826e0258a9b	student_certificates	update	t
a92a555c-276a-47d9-89fd-0924b7ff5951	2fe97570-0740-44c5-911f-9826e0258a9b	student_certificates	delete	t
8f53f2ee-696d-4638-b006-c95322e4329d	2fe97570-0740-44c5-911f-9826e0258a9b	student_certificates	list	t
48ad7416-927c-447c-abac-edfc48f84b48	2fe97570-0740-44c5-911f-9826e0258a9b	student_documents	create	t
c3746b0a-8931-4aa4-91c0-403e02f222c4	2fe97570-0740-44c5-911f-9826e0258a9b	student_documents	read	t
d977c326-dedd-424b-9021-da9b2ff7029c	2fe97570-0740-44c5-911f-9826e0258a9b	student_documents	update	t
edf3958c-6567-4afb-99ba-c594c8c69c36	2fe97570-0740-44c5-911f-9826e0258a9b	student_documents	delete	t
2c2b1bb0-735e-4625-8d7b-5b58a6b8c78e	2fe97570-0740-44c5-911f-9826e0258a9b	student_documents	list	t
f53c905f-025e-4ba1-a947-f07020f66d83	2fe97570-0740-44c5-911f-9826e0258a9b	student_transport	create	t
9698f1cf-504e-4427-84cc-b4528912d759	2fe97570-0740-44c5-911f-9826e0258a9b	student_transport	read	t
f5421645-e834-4997-8108-632762a0a60f	2fe97570-0740-44c5-911f-9826e0258a9b	student_transport	update	t
f34fe07e-83e6-462f-b827-0894c24ac3c9	2fe97570-0740-44c5-911f-9826e0258a9b	student_transport	delete	t
4dea7f1b-1297-49f6-9ddc-0d32c39a2f56	2fe97570-0740-44c5-911f-9826e0258a9b	student_transport	list	t
d521eb49-7262-4079-bd59-9a2f2448f404	2fe97570-0740-44c5-911f-9826e0258a9b	parents	create	t
fffb82c0-cd43-43dd-9e3d-2a5674a2c509	2fe97570-0740-44c5-911f-9826e0258a9b	parents	read	t
c10de7da-c52f-4209-a982-77cc35d00fc0	2fe97570-0740-44c5-911f-9826e0258a9b	parents	update	t
28e5539f-ebf8-4a00-8f24-320adb888e77	2fe97570-0740-44c5-911f-9826e0258a9b	parents	delete	t
c4d98f8c-63bc-441d-a3c5-bfd50121d457	2fe97570-0740-44c5-911f-9826e0258a9b	parents	list	t
1702c036-ecb6-4df9-93c5-01aba98ec6af	2fe97570-0740-44c5-911f-9826e0258a9b	holiday_management	create	t
326de618-3976-4938-8a77-e770dd0ffe5d	2fe97570-0740-44c5-911f-9826e0258a9b	holiday_management	read	t
5d21f1df-9c42-4f28-8933-27de4d67506c	2fe97570-0740-44c5-911f-9826e0258a9b	holiday_management	update	t
7c29e57a-76b0-4802-a172-f0fdc2f30c2e	2fe97570-0740-44c5-911f-9826e0258a9b	holiday_management	delete	t
12a89494-93c1-4fe2-94af-c153f45da665	2fe97570-0740-44c5-911f-9826e0258a9b	holiday_management	list	t
63d9abcf-186f-4c05-9214-522d35766bbe	2fe97570-0740-44c5-911f-9826e0258a9b	holidays	create	t
a39b1784-d92e-49e4-8232-3277b30ceca3	2fe97570-0740-44c5-911f-9826e0258a9b	holidays	read	t
dc11d0b3-723d-42fe-b477-18a887421308	2fe97570-0740-44c5-911f-9826e0258a9b	holidays	update	t
d699808c-6fe8-4f07-835b-958807c38596	2fe97570-0740-44c5-911f-9826e0258a9b	holidays	delete	t
9f7a9876-e041-4617-aa5f-28296bb6b195	2fe97570-0740-44c5-911f-9826e0258a9b	holidays	list	t
ec7ec1c5-6078-4482-bf53-5e7b7560690b	2fe97570-0740-44c5-911f-9826e0258a9b	route_stops	create	t
32c1265b-4d61-46a2-a5a2-bec12a9ec4b2	2fe97570-0740-44c5-911f-9826e0258a9b	route_stops	read	t
4c56c0be-dfd7-489b-9d12-fede041ae086	2fe97570-0740-44c5-911f-9826e0258a9b	route_stops	update	t
2d290ab4-4a72-4225-8911-8894657d460f	2fe97570-0740-44c5-911f-9826e0258a9b	route_stops	delete	t
30210c61-70b4-42dc-b185-439387ca7855	2fe97570-0740-44c5-911f-9826e0258a9b	route_stops	list	t
c36ac198-5c85-446e-a945-c63e38e1b584	2fe97570-0740-44c5-911f-9826e0258a9b	transport_routes	create	t
e043a1f8-4c5e-483f-baf7-4b760937ceb1	2fe97570-0740-44c5-911f-9826e0258a9b	transport_routes	read	t
f5ec7e72-379f-4e45-b46e-983d666fbbf0	2fe97570-0740-44c5-911f-9826e0258a9b	transport_routes	update	t
968dba6b-de45-4280-82ac-4d44cb3b328a	2fe97570-0740-44c5-911f-9826e0258a9b	transport_routes	delete	t
a7328836-0c14-41c8-8b0c-9668a0737b04	2fe97570-0740-44c5-911f-9826e0258a9b	transport_routes	list	t
f11ce7d1-a78b-43d5-b69e-ad6094608947	2fe97570-0740-44c5-911f-9826e0258a9b	transport_trips	create	t
ff15d89c-5086-4f50-8d32-fc1187fc94d3	2fe97570-0740-44c5-911f-9826e0258a9b	transport_trips	read	t
cd80e561-166d-4a64-982d-fded9ba29d4d	2fe97570-0740-44c5-911f-9826e0258a9b	transport_trips	update	t
a4921457-c96d-43bd-95a7-e7ef8078c8e1	2fe97570-0740-44c5-911f-9826e0258a9b	transport_trips	delete	t
ecb78878-9012-4538-8747-ae40f113689d	2fe97570-0740-44c5-911f-9826e0258a9b	transport_trips	list	t
602625e7-0fcc-4437-8bca-48027f702e1e	2fe97570-0740-44c5-911f-9826e0258a9b	transport_vehicles	create	t
1470986d-9ddf-461c-a8bb-0415767f2cd1	2fe97570-0740-44c5-911f-9826e0258a9b	transport_vehicles	read	t
08661e79-c795-431a-8e6c-fc3f55168f60	2fe97570-0740-44c5-911f-9826e0258a9b	transport_vehicles	update	t
52f1ac97-5b0b-4479-8561-33d41889d8a4	2fe97570-0740-44c5-911f-9826e0258a9b	transport_vehicles	delete	t
cdc39c4a-1fab-4a4a-ac2b-ca7a0ad6e19d	2fe97570-0740-44c5-911f-9826e0258a9b	transport_vehicles	list	t
06f37321-acdd-4c09-9792-e80144fbdec8	2fe97570-0740-44c5-911f-9826e0258a9b	role_management	create	t
0c0b1952-c2d2-4993-a4f6-17610429c09a	2fe97570-0740-44c5-911f-9826e0258a9b	role_management	read	t
99a562ba-9e37-46b5-825c-9b11e985a19b	2fe97570-0740-44c5-911f-9826e0258a9b	role_management	update	t
fd9eb45e-c316-4557-b878-201a08b8944f	2fe97570-0740-44c5-911f-9826e0258a9b	role_management	delete	t
89b3bac4-0cb4-47c8-8e69-e8f6d8bdfa45	2fe97570-0740-44c5-911f-9826e0258a9b	role_management	list	t
c0d1350a-e4a5-4985-b91a-3c612eeacb4c	2fe97570-0740-44c5-911f-9826e0258a9b	menu_management	create	t
73ba8bab-ad21-4a65-b555-f2c087266446	2fe97570-0740-44c5-911f-9826e0258a9b	menu_management	read	t
f356af66-2022-4b64-8245-8f7b91dae8f9	2fe97570-0740-44c5-911f-9826e0258a9b	menu_management	update	t
abd8c06e-dc9f-4565-81a6-85c3bef934d1	2fe97570-0740-44c5-911f-9826e0258a9b	menu_management	delete	t
0bd7924f-1281-4fbd-ba3f-fe8dab2aae79	2fe97570-0740-44c5-911f-9826e0258a9b	menu_management	list	t
1d65f0e4-e711-4d10-b211-fc63e7d76e36	2fe97570-0740-44c5-911f-9826e0258a9b	permission_management	create	t
54d3c55c-f245-4066-b8c2-47937e63c07f	2fe97570-0740-44c5-911f-9826e0258a9b	permission_management	read	t
1ea17dfa-790d-4815-84b8-73e12dc90e6c	2fe97570-0740-44c5-911f-9826e0258a9b	permission_management	update	t
74b6b45a-1a92-4763-8e10-c18c0e7bd600	2fe97570-0740-44c5-911f-9826e0258a9b	permission_management	delete	t
e024103e-6094-4f1d-8b8d-0f36c06d287e	2fe97570-0740-44c5-911f-9826e0258a9b	permission_management	list	t
d1f2431b-d957-4ec0-ae70-bd03fcffe4f1	2fe97570-0740-44c5-911f-9826e0258a9b	timetable_management	create	t
3d70077f-f20c-4f46-b76a-923866e609ca	2fe97570-0740-44c5-911f-9826e0258a9b	timetable_management	read	t
85b499e0-bc34-4683-9474-1eca0d7fe47e	2fe97570-0740-44c5-911f-9826e0258a9b	timetable_management	update	t
b8d719c9-113f-4623-a3fa-4a6783e81c27	2fe97570-0740-44c5-911f-9826e0258a9b	timetable_management	delete	t
49b17eab-12dd-4774-9b7c-39d04b201d25	2fe97570-0740-44c5-911f-9826e0258a9b	timetable_management	list	t
ac8024ca-f99e-4eca-8da0-442bdaec8f97	2fe97570-0740-44c5-911f-9826e0258a9b	fee_transactions	create	t
dca36e41-b410-466b-ad0a-5196d6694242	2fe97570-0740-44c5-911f-9826e0258a9b	fee_transactions	read	t
888fedb6-23c0-4113-aa33-6747a0606459	2fe97570-0740-44c5-911f-9826e0258a9b	fee_transactions	update	t
81aef5a6-bb5a-447e-904f-b521623885b2	2fe97570-0740-44c5-911f-9826e0258a9b	fee_transactions	delete	t
14bec2d9-3db6-4e7f-89d8-61842152b0b7	2fe97570-0740-44c5-911f-9826e0258a9b	fee_transactions	list	t
6e363e5c-f6ba-47bd-aab0-07eebd6405e9	2fe97570-0740-44c5-911f-9826e0258a9b	fee_receipts	create	t
da32bda9-5822-447f-8dbb-a6bc68fb1c34	2fe97570-0740-44c5-911f-9826e0258a9b	fee_receipts	read	t
afa7478a-94b5-4afe-b0d8-7ee42e858172	2fe97570-0740-44c5-911f-9826e0258a9b	fee_receipts	update	t
110526e7-a829-48d6-9b3d-dcd9aa6ee731	2fe97570-0740-44c5-911f-9826e0258a9b	fee_receipts	delete	t
b60f228a-352d-4a23-b808-60d9b2222a3d	2fe97570-0740-44c5-911f-9826e0258a9b	fee_receipts	list	t
9c889ce2-0374-42a5-b3da-8af17f486baf	2fe97570-0740-44c5-911f-9826e0258a9b	fee_refunds	create	t
3755cacc-5199-4e1c-8200-3c2b1ac608c9	2fe97570-0740-44c5-911f-9826e0258a9b	fee_refunds	read	t
1eb12016-9fb3-492f-b94e-ced0582f94a6	2fe97570-0740-44c5-911f-9826e0258a9b	fee_refunds	update	t
69c7aaea-5d00-48ef-b91c-82d0d0c172ef	2fe97570-0740-44c5-911f-9826e0258a9b	fee_refunds	delete	t
efda550d-93ba-496a-883a-8177bc12f97c	2fe97570-0740-44c5-911f-9826e0258a9b	fee_refunds	list	t
9e220356-dc6e-43e6-9f14-4589d3a51227	2fe97570-0740-44c5-911f-9826e0258a9b	fee_refunds	approve	t
c1337a45-1ade-488c-90e6-4b53b46cd29a	2fe97570-0740-44c5-911f-9826e0258a9b	fee_refunds	process	t
9bfcf1b1-b190-4f15-b2b6-de83cc9deb55	550e8400-e29b-41d4-a716-446655440001	expense_categories	create	t
506a995c-2b85-4572-b073-22165bc38df9	550e8400-e29b-41d4-a716-446655440001	expense_categories	read	t
caf8e315-826a-4107-9704-5a563fff772f	550e8400-e29b-41d4-a716-446655440001	expense_categories	update	t
5e86be86-2418-48b4-a1ac-267cc8dc1535	550e8400-e29b-41d4-a716-446655440001	expense_categories	delete	t
71163621-e824-4cb9-8170-1b72e725e652	550e8400-e29b-41d4-a716-446655440001	expense_categories	list	t
a0440a7b-2755-40b9-9aee-5d306a1d44fc	550e8400-e29b-41d4-a716-446655440001	expense_types	create	t
60e3042e-af02-46fc-9ab9-eb2ccedd850a	550e8400-e29b-41d4-a716-446655440001	expense_types	read	t
5b244367-cc72-412b-a4ee-24b2999e438c	550e8400-e29b-41d4-a716-446655440001	expense_types	update	t
37e0fe48-fc91-459f-bb8b-22c95648c607	550e8400-e29b-41d4-a716-446655440001	expense_types	delete	t
1dfac79d-acc3-4c8e-ba85-38ae1497b890	550e8400-e29b-41d4-a716-446655440001	expense_types	list	t
6b12312e-e8f3-4dd8-8ddf-15fa400179f8	550e8400-e29b-41d4-a716-446655440001	expense_transactions	create	t
98567eef-cdf3-48fa-8755-2283c14bc778	550e8400-e29b-41d4-a716-446655440001	expense_transactions	read	t
a0da7ef8-ff69-43a0-80e9-70fe608b99a9	550e8400-e29b-41d4-a716-446655440001	expense_transactions	update	t
3e18277f-b403-4f3b-9845-539af8c6f92d	550e8400-e29b-41d4-a716-446655440001	expense_transactions	delete	t
c673ccf2-e53e-4a4f-96cc-eaa6f667bebf	550e8400-e29b-41d4-a716-446655440001	expense_transactions	list	t
717b005e-674c-44c5-b5a3-d3bffb6814ad	550e8400-e29b-41d4-a716-446655440001	expense_transaction_items	create	t
8bd0d1a7-e17a-4178-a44d-f85aa248fa14	550e8400-e29b-41d4-a716-446655440001	expense_transaction_items	read	t
cb07d787-840f-4795-bcf9-a2abb0aa07e4	550e8400-e29b-41d4-a716-446655440001	expense_transaction_items	update	t
df1a344c-c95c-4f9f-9c92-120fae72b66a	550e8400-e29b-41d4-a716-446655440001	expense_transaction_items	delete	t
2d00992b-309e-4a0d-a0ad-84999dabafad	550e8400-e29b-41d4-a716-446655440001	expense_transaction_items	list	t
d7824f1f-4703-4eb3-a4f4-11d64c792167	550e8400-e29b-41d4-a716-446655440001	expense_attachments	create	t
6990c715-344c-4abd-a7fc-3711cec3b0da	550e8400-e29b-41d4-a716-446655440001	expense_attachments	read	t
5dd31d4e-2d75-4c2f-9b5f-ea9f4c94cd09	550e8400-e29b-41d4-a716-446655440001	expense_attachments	update	t
8a3d3b8a-9b40-417e-b3c9-f9deb9d99daa	550e8400-e29b-41d4-a716-446655440001	expense_attachments	delete	t
f342cd3f-5637-4a0b-b1e0-32a3ca432fc5	550e8400-e29b-41d4-a716-446655440001	expense_attachments	list	t
ea31dfd8-9bd1-407e-9f99-fb02363714cd	550e8400-e29b-41d4-a716-446655440001	expense_settings	create	t
046d8051-ad44-41ef-8d8e-83da24200277	550e8400-e29b-41d4-a716-446655440001	expense_settings	read	t
31ce6433-9e0b-4b04-84de-e6bfd3ebd5ae	550e8400-e29b-41d4-a716-446655440001	expense_settings	update	t
a27cf8ee-ff47-4b8c-9aaa-f942a5db46e5	550e8400-e29b-41d4-a716-446655440001	expense_settings	delete	t
142f904c-2be8-47bc-b3cc-ef35eeabf619	550e8400-e29b-41d4-a716-446655440001	expense_settings	list	t
fd63d55a-6654-4f4b-8c49-be49be4d7c96	550e8400-e29b-41d4-a716-446655440001	expense_audit_logs	create	t
9b9e2535-610b-483e-928d-83a02ca75ee3	550e8400-e29b-41d4-a716-446655440001	expense_audit_logs	read	t
d392cb31-a1a3-4e66-9ae1-54078b9c917e	550e8400-e29b-41d4-a716-446655440001	expense_audit_logs	update	t
86b620ab-729b-4924-a3d1-a19b67d4837f	550e8400-e29b-41d4-a716-446655440001	expense_audit_logs	delete	t
5e11c57d-454a-4e3e-b1f2-db4344213cee	550e8400-e29b-41d4-a716-446655440001	expense_audit_logs	list	t
4ac1bd2b-0819-44f6-8fda-eb07938c8286	550e8400-e29b-41d4-a716-446655440001	expense_reports	create	t
6cd0d1b2-4c7c-4a1e-b5e0-0450c576e36f	550e8400-e29b-41d4-a716-446655440001	expense_reports	read	t
9c5fabb6-baa7-4c3f-82ac-ffd8f727484f	550e8400-e29b-41d4-a716-446655440001	expense_reports	update	t
4dfeb512-0b57-42d0-ba69-98a4057535d8	550e8400-e29b-41d4-a716-446655440001	expense_reports	delete	t
300bcee4-2a78-4fc5-906d-d01b3db9b38d	550e8400-e29b-41d4-a716-446655440001	expense_reports	list	t
74e52a9e-a9ef-4748-bbea-f4a731c574bd	2fe97570-0740-44c5-911f-9826e0258a9b	expense_categories	create	t
aa096ed9-e569-48f8-8890-32fb295d01dd	2fe97570-0740-44c5-911f-9826e0258a9b	expense_categories	read	t
8e643f3a-0224-462c-a5d7-e1f43e282344	2fe97570-0740-44c5-911f-9826e0258a9b	expense_categories	update	t
fdb0e644-6055-486f-8c2f-77ef1acb1dd8	2fe97570-0740-44c5-911f-9826e0258a9b	expense_categories	delete	t
0ed48976-823e-4857-85c5-538d36ae2871	2fe97570-0740-44c5-911f-9826e0258a9b	expense_categories	list	t
73382081-fd93-4c44-8bb5-d3e6011a42e7	2fe97570-0740-44c5-911f-9826e0258a9b	expense_types	create	t
119aacfd-8b53-4a9a-b591-bcf356752b91	2fe97570-0740-44c5-911f-9826e0258a9b	expense_types	read	t
f0f40cbd-f017-434d-8579-a53abbdbadb9	2fe97570-0740-44c5-911f-9826e0258a9b	expense_types	update	t
9fddb65e-ba07-4968-89f6-3f35d44bf5b3	2fe97570-0740-44c5-911f-9826e0258a9b	expense_types	delete	t
723c383a-b93a-4496-b553-c4a26424b99b	2fe97570-0740-44c5-911f-9826e0258a9b	expense_types	list	t
857041fc-0b0a-4ba0-a4c3-402aeeceb108	2fe97570-0740-44c5-911f-9826e0258a9b	expense_transactions	create	t
5f4a369e-2f70-444e-903e-4f9239b9be1d	2fe97570-0740-44c5-911f-9826e0258a9b	expense_transactions	read	t
f5d3078f-111a-4f61-8864-2ab3cf5bec68	2fe97570-0740-44c5-911f-9826e0258a9b	expense_transactions	update	t
e1230837-b73f-4905-9bd1-b96ca872e0e2	2fe97570-0740-44c5-911f-9826e0258a9b	expense_transactions	delete	t
457ce8c9-88a1-4407-94c9-dfe687074e25	2fe97570-0740-44c5-911f-9826e0258a9b	expense_transactions	list	t
673d3bc5-6b30-412e-92f1-f8fd208f4d28	2fe97570-0740-44c5-911f-9826e0258a9b	expense_transaction_items	create	t
79d9ce97-01ef-487a-b440-6583cf1ed45c	2fe97570-0740-44c5-911f-9826e0258a9b	expense_transaction_items	read	t
01ea89e0-0156-47bd-8c52-3233af48ae91	2fe97570-0740-44c5-911f-9826e0258a9b	expense_transaction_items	update	t
deba16e1-1fba-41f9-9372-54e3c6784d6e	2fe97570-0740-44c5-911f-9826e0258a9b	expense_transaction_items	delete	t
3d8637aa-83f9-4760-ba41-d3cfe615e67b	2fe97570-0740-44c5-911f-9826e0258a9b	expense_transaction_items	list	t
847e7aff-f818-46ec-b716-5f86e8740967	2fe97570-0740-44c5-911f-9826e0258a9b	expense_attachments	create	t
2e0f354f-4878-4c36-8581-cc5d57b7af72	2fe97570-0740-44c5-911f-9826e0258a9b	expense_attachments	read	t
46f5545e-b10f-489c-aa88-ae57bbeaf7fa	2fe97570-0740-44c5-911f-9826e0258a9b	expense_attachments	update	t
4de1520e-f8c1-4cb5-a3a9-88c7c106eaec	2fe97570-0740-44c5-911f-9826e0258a9b	expense_attachments	delete	t
6c13c15d-49ea-449d-8264-da117c588440	2fe97570-0740-44c5-911f-9826e0258a9b	expense_attachments	list	t
e2869472-6ccf-4e75-9ad1-fc37ca6bfdca	2fe97570-0740-44c5-911f-9826e0258a9b	expense_settings	create	t
08bb806e-8110-458e-9fc3-871680f0d3a9	2fe97570-0740-44c5-911f-9826e0258a9b	expense_settings	read	t
47cb574c-8098-4030-a74b-a36308130c6a	2fe97570-0740-44c5-911f-9826e0258a9b	expense_settings	update	t
ce7338fa-9da0-4e1b-bd4e-de826392cfc2	2fe97570-0740-44c5-911f-9826e0258a9b	expense_settings	delete	t
037a343d-4a8a-4279-93e0-ef6ff1908efb	2fe97570-0740-44c5-911f-9826e0258a9b	expense_settings	list	t
d6a7ba3e-3770-4844-b84f-581b0343c45e	2fe97570-0740-44c5-911f-9826e0258a9b	expense_audit_logs	create	t
a657032d-2a2b-4c5e-8c6b-b16b4a75f005	2fe97570-0740-44c5-911f-9826e0258a9b	expense_audit_logs	read	t
0c5a7c24-7e8f-4f5a-b3c1-545c62ef7150	2fe97570-0740-44c5-911f-9826e0258a9b	expense_audit_logs	update	t
935a4916-e2b8-482e-9ef9-afa3f4d9a681	2fe97570-0740-44c5-911f-9826e0258a9b	expense_audit_logs	delete	t
3f02d153-d97f-478e-9039-55f5eb023fa9	2fe97570-0740-44c5-911f-9826e0258a9b	expense_audit_logs	list	t
7744d81d-357c-49a6-b429-e82e2fff8968	2fe97570-0740-44c5-911f-9826e0258a9b	expense_reports	create	t
eeb58b7e-a237-4c72-9229-74d6f5fde741	2fe97570-0740-44c5-911f-9826e0258a9b	expense_reports	read	t
ea648914-42e8-4d4c-9bf1-cbfcc81616c2	2fe97570-0740-44c5-911f-9826e0258a9b	expense_reports	update	t
19c57dc2-4823-4c37-b12d-1fa428674a72	2fe97570-0740-44c5-911f-9826e0258a9b	expense_reports	delete	t
43758e3f-1f89-40b0-8210-1f27dbac413c	2fe97570-0740-44c5-911f-9826e0258a9b	expense_reports	list	t
\.


--
-- Data for Name: role_inheritance; Type: TABLE DATA; Schema: test_tenant_schema; Owner: postgres
--

COPY test_tenant_schema.role_inheritance (id, tenant_role_id, public_role_template_id, is_active) FROM stdin;
\.


--
-- Data for Name: role_menu_permissions; Type: TABLE DATA; Schema: test_tenant_schema; Owner: postgres
--

COPY test_tenant_schema.role_menu_permissions (id, role_id, menu_id, can_view, can_edit) FROM stdin;
aa856ba2-bfbf-424f-b27c-ad1a7be8bc03	2fe97570-0740-44c5-911f-9826e0258a9b	8cb23322-0e9d-406f-9908-73bb6a82550f	t	t
ce6dda6d-6121-4c8d-b50d-af7f1b2ba893	2fe97570-0740-44c5-911f-9826e0258a9b	dfd80d48-67fd-4a80-aeec-5e51a5348d9d	t	t
568f78e0-6d85-4c34-81ad-5c9b4c017dcc	2fe97570-0740-44c5-911f-9826e0258a9b	fbc4bfb1-42eb-4816-b514-52fc2a98611e	t	t
7a28ec13-6788-46d0-9457-53cc58fe2745	2fe97570-0740-44c5-911f-9826e0258a9b	6fb61634-9000-4165-9ad7-435b9d71bc24	t	t
fbe7979c-9272-4476-af84-5ba377559efc	2fe97570-0740-44c5-911f-9826e0258a9b	b415224d-8058-40f7-8107-d15e7ef69dcc	t	t
ad37c85d-9eaf-4b2a-883b-2d6a5601bb75	2fe97570-0740-44c5-911f-9826e0258a9b	8792498d-df9a-4a95-84a9-aa333e4e6844	t	t
a3a00414-0a00-4850-8eee-1d244640d36d	2fe97570-0740-44c5-911f-9826e0258a9b	e0ad58c0-6c72-4930-9c24-f951ef0b42b5	t	t
381f4102-5beb-4632-a50a-371ba8e7096a	2fe97570-0740-44c5-911f-9826e0258a9b	fead4d8f-46fc-4b60-9cbd-88c3e1fc225a	t	t
a124e422-00bc-4a4e-8d55-5086038833a0	2fe97570-0740-44c5-911f-9826e0258a9b	64b8a80a-6d7a-4b81-a161-d8374ccd79ec	t	t
25d44337-7203-460c-a700-5da7999c9ee5	2fe97570-0740-44c5-911f-9826e0258a9b	3c2ea797-32ae-49db-88de-83fcac59bbb2	t	t
1c4a02e0-8a1f-40fb-aa65-59f06666b960	2fe97570-0740-44c5-911f-9826e0258a9b	bb2f9ca7-80fc-44c4-957e-ffa84dc1c181	t	t
1f69a9f0-2bfc-435e-8155-39ef6117a798	2fe97570-0740-44c5-911f-9826e0258a9b	a36e50ed-9547-4b79-bf3e-6090294d03a3	t	t
97b676b9-ec54-4200-9faa-e532618832e6	2fe97570-0740-44c5-911f-9826e0258a9b	92446059-113a-4961-9c1c-ce8e29a2880f	t	t
b35b27fe-78fe-4df8-a931-b727ac5db7e3	2fe97570-0740-44c5-911f-9826e0258a9b	c2de843f-517d-4370-a670-3a44b857a777	t	t
55feb85d-f610-4279-9e6b-3b9ea83fb768	2fe97570-0740-44c5-911f-9826e0258a9b	6e230039-387d-441a-8e9e-01bb0416a6eb	t	t
f24fdca0-2d47-4b89-a6bd-aa0c9773695f	2fe97570-0740-44c5-911f-9826e0258a9b	132299aa-5c3a-4be6-8260-9d6e6fa630c5	t	t
d1481912-8e41-4109-bc05-e1cebb826176	2fe97570-0740-44c5-911f-9826e0258a9b	562075e7-9d0c-47fb-8cdf-ed2075637c51	t	t
5e51d036-ede1-4553-8a5c-056791c03233	2fe97570-0740-44c5-911f-9826e0258a9b	7857839b-1fa6-48cd-b4ff-19b83ef6d2cc	t	t
c73f12ac-f8ac-44fa-abdb-6e7f34398ddb	2fe97570-0740-44c5-911f-9826e0258a9b	71b7ce7e-ea13-4d2e-8509-70523f63b4be	t	t
de54f476-f33b-47cb-85d7-a37057633674	2fe97570-0740-44c5-911f-9826e0258a9b	6111b863-e6da-444d-a6a1-31c03c7b2cee	t	t
213cd1fc-380d-4478-a70b-bf9eaf61cc58	2fe97570-0740-44c5-911f-9826e0258a9b	cf4c4594-eb27-4863-964d-56a7ebd3997a	t	t
502f1ffa-f91f-4ae6-9bbc-fdbaebbcf3f0	2fe97570-0740-44c5-911f-9826e0258a9b	3cc15a0a-800c-4cd0-8986-3273da640a78	t	t
8ea1ae49-ca5f-457e-8796-30f11cab541f	2fe97570-0740-44c5-911f-9826e0258a9b	9772e642-0600-4242-aa7f-d79eee8959eb	t	t
108aa7d2-c3ad-4885-8100-778314c3aed5	2fe97570-0740-44c5-911f-9826e0258a9b	4df6e384-bb0d-45f7-b035-8946e64454c0	t	t
561fe42e-5ae8-43fd-b594-0a0e2e5de9de	2fe97570-0740-44c5-911f-9826e0258a9b	59b104a7-c8fb-4567-9cd2-a157e97b5018	t	t
1f80498a-04f8-4e64-a71b-b7e50a2f379e	2fe97570-0740-44c5-911f-9826e0258a9b	57809a83-add0-48ac-894a-b6d2899863f1	t	t
a372883c-219c-47da-9a7f-50c79adf8605	2fe97570-0740-44c5-911f-9826e0258a9b	766afdef-05e6-4195-b103-bd8198a33cfe	t	t
dda82e1b-3491-4630-8549-fec9514f9fe2	2fe97570-0740-44c5-911f-9826e0258a9b	694fb8ea-8aa4-444b-a551-550759ca79a9	t	t
16aab213-9fd0-4089-86c6-0d08ebc986e2	2fe97570-0740-44c5-911f-9826e0258a9b	2092884a-4fc9-40cd-bee8-99cc3c5a0212	t	t
1d6fd1c9-3faf-4abc-ac5b-2802b9ace451	2fe97570-0740-44c5-911f-9826e0258a9b	28f266c8-6096-4ec2-ae92-607647570bd7	t	t
bc59fbcd-de11-43dd-88ed-ec8fb18f9740	2fe97570-0740-44c5-911f-9826e0258a9b	4f804896-c88a-49b2-b4de-c6de3f1558c3	t	t
2c298856-0e3b-42f9-abb1-589f8c31e12e	2fe97570-0740-44c5-911f-9826e0258a9b	bf6e49fb-ecf1-4ce9-8eaf-87a572916bf9	t	t
e97bd39e-c0d8-46c9-b6b2-6e4adfd5d4f5	2fe97570-0740-44c5-911f-9826e0258a9b	46760949-79fc-49f7-93d0-9bdac2b50f07	t	t
2a754eee-940e-4576-8856-c962a22f804b	2fe97570-0740-44c5-911f-9826e0258a9b	ecc64393-c892-4721-b630-47c199274609	t	t
47cd3fcb-dea4-45e1-a405-91fb76b2a9d7	2fe97570-0740-44c5-911f-9826e0258a9b	d7f5e4d5-63e0-42a1-aa44-1f22b6ea5cad	t	t
36148827-533c-4998-82e5-b9ec8372a026	2fe97570-0740-44c5-911f-9826e0258a9b	177774ab-89f6-405c-9ab9-20fd1fdfd27a	t	t
10a6834d-d6bd-4bc9-8681-799d8a54dabb	2fe97570-0740-44c5-911f-9826e0258a9b	59a7e53b-aa6d-46c7-855d-d07004c4c287	t	t
ade7090b-0e65-411d-8aa2-ff4909b371fe	2fe97570-0740-44c5-911f-9826e0258a9b	7dc5ae2c-17d5-42a6-a5bc-88b88ec3760c	t	t
eb29d4f9-f889-4818-8a81-e7b31a6d91f6	2fe97570-0740-44c5-911f-9826e0258a9b	20b5f5c5-50ee-4195-9f9a-09b6e6ac5ff5	t	t
c66e4c7b-1e04-4744-bd53-858c9c248395	2fe97570-0740-44c5-911f-9826e0258a9b	09fd0888-5569-40b9-969c-421bf9a47833	t	t
9e380b48-e3fe-405e-8040-e44bb5983e14	2fe97570-0740-44c5-911f-9826e0258a9b	5687ca06-e8b4-488f-966c-290f8b4ac824	t	t
04253c2c-b834-4f10-b6f9-7b14bdcf98a3	2fe97570-0740-44c5-911f-9826e0258a9b	e7395635-aa1b-4c41-b929-1be78e989e6f	t	t
208dfe1c-5c68-4958-a980-d4029cedb62b	2fe97570-0740-44c5-911f-9826e0258a9b	89a39c8f-f0a3-4ec7-9f1a-cb3f6572f4a4	t	t
ac7b2d0b-5777-45ad-8286-d87541730535	2fe97570-0740-44c5-911f-9826e0258a9b	729a3689-8e0c-490a-a574-cd4a19f48530	t	t
421a20b3-56e0-41c2-b2e7-44ab3ce5c314	2fe97570-0740-44c5-911f-9826e0258a9b	83216c1d-fa8d-41db-881d-3d238bef4422	t	t
4420841d-6a33-4289-9736-d5002ae7b6fb	2fe97570-0740-44c5-911f-9826e0258a9b	29204691-4ea0-478e-84bd-5c6e4a349aa5	t	t
21c4180d-7eea-4200-bb32-043e5a34e8ba	2fe97570-0740-44c5-911f-9826e0258a9b	37cfe65d-dcf9-49c9-9e6b-1d64483b1564	t	t
f8b45308-3d81-46cb-8cfb-a9b81e9f7fd8	2fe97570-0740-44c5-911f-9826e0258a9b	9aa19eca-1b01-448f-8fe3-b29ff7f2efe0	t	t
edc69323-6c4e-4bae-be04-e44dbf4d9786	2fe97570-0740-44c5-911f-9826e0258a9b	9e27304b-f4a9-4d13-8a6c-784354c33a57	t	t
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: test_tenant_schema; Owner: postgres
--

COPY test_tenant_schema.roles (id, name, description, is_system_role, is_custom_role) FROM stdin;
2fe97570-0740-44c5-911f-9826e0258a9b	Admin	Administrator with full system access	t	f
d093a9bf-2729-40c7-872d-19a5ee112b9c	Test Role 2f905bb7	Test role for automated testing - 2025-09-10T05:49:12.820Z	f	f
819304fb-b753-43b8-bf27-e5a4f1066649	Verification Role c0f5535c	Role for verification testing - c0f5535c	f	f
fcc934f9-3a89-4fb7-aef2-83f70ed8c292	Test Role 8080914a	Test role for automated testing - 2025-09-10T06:36:02.768Z	f	f
f19aa346-400a-44c8-8430-afca3d752aa4	Verification Role 83b028d0	Role for verification testing - 83b028d0	f	f
3a0b1f30-c88a-4cf5-8b84-749c41072774	Delete Test Role fd5911df	Role for deletion testing	f	f
cb916021-1c39-4d51-843e-f264db093647	LibraryManager	Updated: Manages library operations and staff	f	t
e575fd57-9621-4725-add1-5eee0abccebe	TestAdmin	Test administrator role	t	f
bd7f8bd6-5662-4500-8462-f8ed16872f21	TestOnboardingRole	Role created to test automated onboarding process	f	t
\.


--
-- Data for Name: route_stops; Type: TABLE DATA; Schema: test_tenant_schema; Owner: postgres
--

COPY test_tenant_schema.route_stops (id, route_id, name, number, reaching_time, fees, is_active) FROM stdin;
b676b21a-789d-49f4-bc85-97bcfd602102	1b95f46e-8ac9-45a0-a5a1-b04929eaa19a	School Main Gate	1	07:00:00	0	t
a86d5bf9-5bb8-41fa-b5e8-5a0c3c2ad033	1b95f46e-8ac9-45a0-a5a1-b04929eaa19a	City Center	2	07:15:00	500	t
7fce5b2a-0189-47f9-8513-4339c17015d8	1b95f46e-8ac9-45a0-a5a1-b04929eaa19a	Park Street	3	07:25:00	750	t
0036188e-89d1-4926-a615-edb279ceb46e	1b95f46e-8ac9-45a0-a5a1-b04929eaa19a	Mall Entrance	4	07:40:00	1000	t
\.


--
-- Data for Name: routes; Type: TABLE DATA; Schema: test_tenant_schema; Owner: postgres
--

COPY test_tenant_schema.routes (id, route_name, starting_stop, ending_stop, number_of_stops, route_type, trip_type, start_time, end_time, is_active) FROM stdin;
c5ccc948-dbe4-4555-8b5f-fe6e154a6567	Test Route fb7292c8	Test School Gate	Test City Center	5	Regular	Round Trip	07:00:00	08:30:00	t
1b95f46e-8ac9-45a0-a5a1-b04929eaa19a	Updated Test Route School to Mall 1757483545840	School Main Gate	Updated Destination	5	Regular	Round Trip	08:00:00	17:00:00	t
a1871364-d33f-436d-b43e-5eaf32857020	Delete Test Route 851e2346	Delete Test Start	Delete Test End	3	Regular	One Way	09:00:00	10:00:00	f
\.


--
-- Data for Name: sections; Type: TABLE DATA; Schema: test_tenant_schema; Owner: postgres
--

COPY test_tenant_schema.sections (id, name, description, is_active, class_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: slot_times; Type: TABLE DATA; Schema: test_tenant_schema; Owner: postgres
--

COPY test_tenant_schema.slot_times (id, section_id, label, start_time, end_time) FROM stdin;
\.


--
-- Data for Name: staff; Type: TABLE DATA; Schema: test_tenant_schema; Owner: postgres
--

COPY test_tenant_schema.staff (id, first_name, last_name, email, phone, gender, date_of_birth, joining_date, qualification, experience_years, address, designation_id, department, is_active, user_id) FROM stdin;
\.


--
-- Data for Name: staff_attendance; Type: TABLE DATA; Schema: test_tenant_schema; Owner: postgres
--

COPY test_tenant_schema.staff_attendance (id, staff_id, date, status) FROM stdin;
\.


--
-- Data for Name: student_admissions; Type: TABLE DATA; Schema: test_tenant_schema; Owner: postgres
--

COPY test_tenant_schema.student_admissions (id, student_id, admission_number, admission_date, academic_year_id, admitted_academic_year_id, admitted_class_id, admitted_section_id, current_class_id, current_section_id, address_line1, address_line2, city, state, is_previous_school, previous_school_name, previous_class, previous_school_remark) FROM stdin;
\.


--
-- Data for Name: student_attendance; Type: TABLE DATA; Schema: test_tenant_schema; Owner: postgres
--

COPY test_tenant_schema.student_attendance (id, student_id, date, status, remarks) FROM stdin;
\.


--
-- Data for Name: student_certificates; Type: TABLE DATA; Schema: test_tenant_schema; Owner: postgres
--

COPY test_tenant_schema.student_certificates (id, student_id, certificate_type_id, issue_date, file_path, remarks) FROM stdin;
\.


--
-- Data for Name: student_documents; Type: TABLE DATA; Schema: test_tenant_schema; Owner: postgres
--

COPY test_tenant_schema.student_documents (id, student_id, document_type, file_path, upload_date) FROM stdin;
\.


--
-- Data for Name: student_homework; Type: TABLE DATA; Schema: test_tenant_schema; Owner: postgres
--

COPY test_tenant_schema.student_homework (id, student_id, subject_id, description, due_date, submission_status) FROM stdin;
\.


--
-- Data for Name: student_parent_links; Type: TABLE DATA; Schema: test_tenant_schema; Owner: postgres
--

COPY test_tenant_schema.student_parent_links (id, student_id, parent_id) FROM stdin;
\.


--
-- Data for Name: student_transport_assignments; Type: TABLE DATA; Schema: test_tenant_schema; Owner: postgres
--

COPY test_tenant_schema.student_transport_assignments (id, student_id, trip_id, stop_id, fee_per_term, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: student_trips; Type: TABLE DATA; Schema: test_tenant_schema; Owner: postgres
--

COPY test_tenant_schema.student_trips (id, trip_id, student_id, stop_id, fee_term_id, fee_per_term, is_active) FROM stdin;
\.


--
-- Data for Name: students; Type: TABLE DATA; Schema: test_tenant_schema; Owner: postgres
--

COPY test_tenant_schema.students (id, first_name, last_name, date_of_birth, gender, is_primary, aadhar_number, apaar_number, caste, sub_caste, community, nationality, mother_tongue, identification_marks, user_id) FROM stdin;
\.


--
-- Data for Name: subject_categories; Type: TABLE DATA; Schema: test_tenant_schema; Owner: postgres
--

COPY test_tenant_schema.subject_categories (id, name) FROM stdin;
dedc333d-e7b9-4c94-bf54-18b8aef5c137	Science 779709cc
175e62a3-c3f0-422c-81a2-c491968e5a50	Test Category 8099197a
aa8dd584-5f88-43a4-adcd-d882b72f0250	Test Category 5a697aaf
01596cd9-3472-4ca4-b56a-577f0d490279	Test Category 96b6706d
3e8e58e1-e870-4b83-810e-f38c6ac70984	Test Category 98d1601d
b40303c1-60f3-4c7e-9991-64296b505518	Verification Test 784f63f8
1fbfdbce-e0fc-49ae-bc6b-099b1eeeadee	Test Category ef89465d
728b0e9f-5cea-41e5-80a8-a69d77e90f66	Verification Test d010dc8c
40f67152-e6b6-4b66-bc17-724a5869df28	Test Category 3e7a1bd3
cccd421f-5b6a-4c2e-860b-2fff85a3e3b4	Verification Test 8f023158
26b0d822-019e-4be2-a4ee-438047624aed	Test Category df921ffe
273bea1d-7d0e-4057-a5e0-eac54708beee	Verification Test 42f9fb36
c202effd-4da6-4175-a1e5-2c64aeefd086	Updated Science Subjects
60fa0ee7-e34b-400f-be82-f09db1318115	Test Category b1e76417
297c2523-a6bb-4396-8785-1d00ff27fbec	Updated Delete Test 7fdf90d6 1757489648564
29c44cc1-c57b-4c73-9430-116c1fe8406e	Test Category FIXED
84e439ae-aa4c-4028-a7c3-a67ad260912f	POST Test Category Success
2c03af5e-d396-4b84-92cf-60f2c39379b7	Test Category e06551a6
79ddf171-af70-44a3-9ff7-47685a293c8a	Updated Duplicate Test f401c1a6 1757513972396
1c04c93b-c566-488b-bd28-dd1222bcf3e2	Duplicate Test 0f4a3f09
\.


--
-- Data for Name: subjects; Type: TABLE DATA; Schema: test_tenant_schema; Owner: postgres
--

COPY test_tenant_schema.subjects (id, name, category_id, is_active, short_code, created_at, updated_at, academic_year_id) FROM stdin;
37ad6d08-a6c2-48a1-b78e-53d837c8e318	Biology Test	644dfce3-397c-4230-a6ac-a76f8597e687	t	BIO	2025-09-11 11:31:00.13541	2025-09-11 11:31:00.13541	43090039-4052-4cc0-bac1-2e7992307cae
c43edff0-f38a-45c9-ae15-74b1626be3bf	Test Subject Success	1c04c93b-c566-488b-bd28-dd1222bcf3e2	t	TEST	2025-09-11 11:39:05.969151	2025-09-11 11:39:05.969151	c8e1ea7d-f2e5-4b49-b515-f29fba63c890
bd52a3d1-f915-4e2b-a616-aeb486ee86a0	Test Subject Fixed	1c04c93b-c566-488b-bd28-dd1222bcf3e2	t	TEST	2025-09-11 11:39:53.501648	2025-09-11 11:39:53.501648	c8e1ea7d-f2e5-4b49-b515-f29fba63c890
73de5ead-2bbc-4ea1-8f42-636b9a03ba74	Debug Test Subject	1c04c93b-c566-488b-bd28-dd1222bcf3e2	t	DEBUG	2025-09-11 11:47:28.573585	2025-09-11 11:47:28.573585	c8e1ea7d-f2e5-4b49-b515-f29fba63c890
14a46378-1e09-4028-bc72-544165c63e33	Test Subject 854cd90c	1c04c93b-c566-488b-bd28-dd1222bcf3e2	t	TST426D	2025-09-11 12:49:59.586953	2025-09-11 12:49:59.586953	fccbedb4-d00b-42e4-bf63-9d5b35294065
5dabeb86-d3b5-4ff8-a846-038cd233ae9d	Delete Test Subject e13b892b	1c04c93b-c566-488b-bd28-dd1222bcf3e2	t	DELDAB9	2025-09-11 12:50:09.332031	2025-09-11 12:50:09.332031	fccbedb4-d00b-42e4-bf63-9d5b35294065
0a237638-02fc-42e9-ba83-dd2b6f4876a8	Test Subject b52beb47	71549a86-00bf-48c1-bac9-c92408ff41c5	t	TSTE051	2025-09-11 12:50:09.849835	2025-09-11 12:50:09.849835	fccbedb4-d00b-42e4-bf63-9d5b35294065
4b9a9a3d-b28a-4ba4-90b5-9afe6b217b95	E2E Test Subject 5446f7e7	1c04c93b-c566-488b-bd28-dd1222bcf3e2	t	E2EBB96	2025-09-11 12:50:10.030128	2025-09-11 12:50:10.030128	fccbedb4-d00b-42e4-bf63-9d5b35294065
\.


--
-- Data for Name: timetable_slots; Type: TABLE DATA; Schema: test_tenant_schema; Owner: postgres
--

COPY test_tenant_schema.timetable_slots (id, timetable_id, day, slot_time_id, is_break, break_label) FROM stdin;
\.


--
-- Data for Name: timetable_subject_options; Type: TABLE DATA; Schema: test_tenant_schema; Owner: postgres
--

COPY test_tenant_schema.timetable_subject_options (id, slot_id, subject_id) FROM stdin;
\.


--
-- Data for Name: timetables; Type: TABLE DATA; Schema: test_tenant_schema; Owner: postgres
--

COPY test_tenant_schema.timetables (id, section_id, created_at) FROM stdin;
\.


--
-- Data for Name: trips; Type: TABLE DATA; Schema: test_tenant_schema; Owner: postgres
--

COPY test_tenant_schema.trips (id, vehicle_id, route_id, driver_id, trip_number) FROM stdin;
b0914e8c-b9c5-434a-a89a-79544c037e9d	8363f749-2f26-48f0-91f4-961d9a6892cd	1b95f46e-8ac9-45a0-a5a1-b04929eaa19a	3f03c2f4-0aaa-4fe1-b254-3a3acc35ec6c	1
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: test_tenant_schema; Owner: postgres
--

COPY test_tenant_schema.users (id, username, email, password_hash, is_active, role_id) FROM stdin;
dfbc9e77-9833-43b6-8769-e2cbf7124c5c	testadmin	testadmin@example.com	$2b$12$gAZv43SogSRmm5XtNnc/R.THSrQAo2wCuTMKi8V.HezixFrmypc3a	t	e575fd57-9621-4725-add1-5eee0abccebe
3f03c2f4-0aaa-4fe1-b254-3a3acc35ec6c	admin	admin@test.com	$2b$12$5yBPzyeIUXG04yjMYcjVrOnGZSj.apr8FBfr1T9i.8vIz7N/bC5Ue	t	2fe97570-0740-44c5-911f-9826e0258a9b
\.


--
-- Data for Name: vehicles; Type: TABLE DATA; Schema: test_tenant_schema; Owner: postgres
--

COPY test_tenant_schema.vehicles (id, name, registration_number, vehicle_type, last_inspected_date, pollution_renewal_date, is_active) FROM stdin;
8363f749-2f26-48f0-91f4-961d9a6892cd	Updated Test School Bus 001 1757485809629	TSB-001	Bus	2024-01-01	2025-12-31	t
b310bbdb-6ac6-464f-825e-a139a6b65268	Delete Test Vehicle 1b7c372a	DEL-5336	Car	2024-01-15	2024-12-31	f
31bf79b3-ec06-4565-b14c-55dd6120175a	Verification Vehicle 29cb7c3e	VER-2230	Van	2024-01-15	2024-12-31	t
614b9b12-847c-4abc-aedc-196086a4ecba	Test Bus e5037f51	MH-12-AB-9679	Bus	2024-01-15	2024-12-31	t
8a16526f-5511-47df-96d6-58f84276942a	Updated Test Bus 6d5b83ab 1757485837769	MH-12-AB-6129	Bus	2024-01-15	2025-12-31	t
518b6d39-dfa6-45f8-b89a-2f1d690d0610	Delete Test Vehicle 323e04a9	DEL-1135	Car	2024-01-15	2024-12-31	f
96749820-48de-4a57-80a5-e1bb5b118208	Verification Vehicle dec00334	VER-6184	Van	2024-01-15	2024-12-31	t
\.


--
-- Name: academic_years academic_years_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.academic_years
    ADD CONSTRAINT academic_years_pkey PRIMARY KEY (id);


--
-- Name: academic_years academic_years_title_key; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.academic_years
    ADD CONSTRAINT academic_years_title_key UNIQUE (title);


--
-- Name: alembic_version alembic_version_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.alembic_version
    ADD CONSTRAINT alembic_version_pkey PRIMARY KEY (version_num);


--
-- Name: certificate_types certificate_types_name_key; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.certificate_types
    ADD CONSTRAINT certificate_types_name_key UNIQUE (name);


--
-- Name: certificate_types certificate_types_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.certificate_types
    ADD CONSTRAINT certificate_types_pkey PRIMARY KEY (id);


--
-- Name: class_subject_mappings class_subject_mappings_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.class_subject_mappings
    ADD CONSTRAINT class_subject_mappings_pkey PRIMARY KEY (id);


--
-- Name: classes classes_name_key; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.classes
    ADD CONSTRAINT classes_name_key UNIQUE (name);


--
-- Name: classes classes_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.classes
    ADD CONSTRAINT classes_pkey PRIMARY KEY (id);


--
-- Name: designations designations_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.designations
    ADD CONSTRAINT designations_pkey PRIMARY KEY (id);


--
-- Name: designations designations_title_key; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.designations
    ADD CONSTRAINT designations_title_key UNIQUE (title);


--
-- Name: expense_attachments expense_attachments_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.expense_attachments
    ADD CONSTRAINT expense_attachments_pkey PRIMARY KEY (id);


--
-- Name: expense_attachments expense_attachments_stored_filename_key; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.expense_attachments
    ADD CONSTRAINT expense_attachments_stored_filename_key UNIQUE (stored_filename);


--
-- Name: expense_audit_logs expense_audit_logs_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.expense_audit_logs
    ADD CONSTRAINT expense_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: expense_categories expense_categories_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.expense_categories
    ADD CONSTRAINT expense_categories_pkey PRIMARY KEY (id);


--
-- Name: expense_settings expense_settings_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.expense_settings
    ADD CONSTRAINT expense_settings_pkey PRIMARY KEY (id);


--
-- Name: expense_transaction_items expense_transaction_items_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.expense_transaction_items
    ADD CONSTRAINT expense_transaction_items_pkey PRIMARY KEY (id);


--
-- Name: expense_transactions expense_transactions_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.expense_transactions
    ADD CONSTRAINT expense_transactions_pkey PRIMARY KEY (id);


--
-- Name: expense_types expense_types_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.expense_types
    ADD CONSTRAINT expense_types_pkey PRIMARY KEY (id);


--
-- Name: fee_categories fee_categories_category_name_academic_year_id_key; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.fee_categories
    ADD CONSTRAINT fee_categories_category_name_academic_year_id_key UNIQUE (category_name, academic_year_id);


--
-- Name: fee_categories fee_categories_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.fee_categories
    ADD CONSTRAINT fee_categories_pkey PRIMARY KEY (id);


--
-- Name: fee_class_map_term_amounts fee_class_map_term_amounts_fee_class_mapping_id_term_id_key; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.fee_class_map_term_amounts
    ADD CONSTRAINT fee_class_map_term_amounts_fee_class_mapping_id_term_id_key UNIQUE (fee_class_mapping_id, term_id);


--
-- Name: fee_class_map_term_amounts fee_class_map_term_amounts_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.fee_class_map_term_amounts
    ADD CONSTRAINT fee_class_map_term_amounts_pkey PRIMARY KEY (id);


--
-- Name: fee_class_mappings fee_class_mappings_class_id_fee_type_id_academic_year_id_key; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.fee_class_mappings
    ADD CONSTRAINT fee_class_mappings_class_id_fee_type_id_academic_year_id_key UNIQUE (class_id, fee_type_id, academic_year_id);


--
-- Name: fee_class_mappings fee_class_mappings_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.fee_class_mappings
    ADD CONSTRAINT fee_class_mappings_pkey PRIMARY KEY (id);


--
-- Name: fee_receipts fee_receipts_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.fee_receipts
    ADD CONSTRAINT fee_receipts_pkey PRIMARY KEY (id);


--
-- Name: fee_refunds fee_refunds_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.fee_refunds
    ADD CONSTRAINT fee_refunds_pkey PRIMARY KEY (id);


--
-- Name: fee_term_dates fee_term_dates_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.fee_term_dates
    ADD CONSTRAINT fee_term_dates_pkey PRIMARY KEY (id);


--
-- Name: fee_terms fee_terms_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.fee_terms
    ADD CONSTRAINT fee_terms_pkey PRIMARY KEY (id);


--
-- Name: fee_transaction_items fee_transaction_items_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.fee_transaction_items
    ADD CONSTRAINT fee_transaction_items_pkey PRIMARY KEY (id);


--
-- Name: fee_transactions fee_transactions_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.fee_transactions
    ADD CONSTRAINT fee_transactions_pkey PRIMARY KEY (id);


--
-- Name: fee_types fee_types_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.fee_types
    ADD CONSTRAINT fee_types_pkey PRIMARY KEY (id);


--
-- Name: fee_types fee_types_type_name_fee_category_id_key; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.fee_types
    ADD CONSTRAINT fee_types_type_name_fee_category_id_key UNIQUE (type_name, fee_category_id);


--
-- Name: holidays holidays_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.holidays
    ADD CONSTRAINT holidays_pkey PRIMARY KEY (id);


--
-- Name: menus menus_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.menus
    ADD CONSTRAINT menus_pkey PRIMARY KEY (id);


--
-- Name: parents parents_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.parents
    ADD CONSTRAINT parents_pkey PRIMARY KEY (id);


--
-- Name: parents parents_user_id_key; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.parents
    ADD CONSTRAINT parents_user_id_key UNIQUE (user_id);


--
-- Name: resource_permissions resource_permissions_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.resource_permissions
    ADD CONSTRAINT resource_permissions_pkey PRIMARY KEY (id);


--
-- Name: resource_permissions resource_permissions_role_id_resource_action_key; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.resource_permissions
    ADD CONSTRAINT resource_permissions_role_id_resource_action_key UNIQUE (role_id, resource, action);


--
-- Name: role_inheritance role_inheritance_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.role_inheritance
    ADD CONSTRAINT role_inheritance_pkey PRIMARY KEY (id);


--
-- Name: role_inheritance role_inheritance_tenant_role_id_key; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.role_inheritance
    ADD CONSTRAINT role_inheritance_tenant_role_id_key UNIQUE (tenant_role_id);


--
-- Name: role_menu_permissions role_menu_permissions_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.role_menu_permissions
    ADD CONSTRAINT role_menu_permissions_pkey PRIMARY KEY (id);


--
-- Name: roles roles_name_key; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.roles
    ADD CONSTRAINT roles_name_key UNIQUE (name);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: route_stops route_stops_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.route_stops
    ADD CONSTRAINT route_stops_pkey PRIMARY KEY (id);


--
-- Name: routes routes_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.routes
    ADD CONSTRAINT routes_pkey PRIMARY KEY (id);


--
-- Name: sections sections_name_key; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.sections
    ADD CONSTRAINT sections_name_key UNIQUE (name);


--
-- Name: sections sections_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.sections
    ADD CONSTRAINT sections_pkey PRIMARY KEY (id);


--
-- Name: slot_times slot_times_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.slot_times
    ADD CONSTRAINT slot_times_pkey PRIMARY KEY (id);


--
-- Name: staff_attendance staff_attendance_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.staff_attendance
    ADD CONSTRAINT staff_attendance_pkey PRIMARY KEY (id);


--
-- Name: staff_attendance staff_attendance_staff_id_date_key; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.staff_attendance
    ADD CONSTRAINT staff_attendance_staff_id_date_key UNIQUE (staff_id, date);


--
-- Name: staff staff_email_key; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.staff
    ADD CONSTRAINT staff_email_key UNIQUE (email);


--
-- Name: staff staff_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.staff
    ADD CONSTRAINT staff_pkey PRIMARY KEY (id);


--
-- Name: staff staff_user_id_key; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.staff
    ADD CONSTRAINT staff_user_id_key UNIQUE (user_id);


--
-- Name: student_admissions student_admissions_admission_number_key; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.student_admissions
    ADD CONSTRAINT student_admissions_admission_number_key UNIQUE (admission_number);


--
-- Name: student_admissions student_admissions_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.student_admissions
    ADD CONSTRAINT student_admissions_pkey PRIMARY KEY (id);


--
-- Name: student_attendance student_attendance_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.student_attendance
    ADD CONSTRAINT student_attendance_pkey PRIMARY KEY (id);


--
-- Name: student_certificates student_certificates_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.student_certificates
    ADD CONSTRAINT student_certificates_pkey PRIMARY KEY (id);


--
-- Name: student_documents student_documents_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.student_documents
    ADD CONSTRAINT student_documents_pkey PRIMARY KEY (id);


--
-- Name: student_homework student_homework_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.student_homework
    ADD CONSTRAINT student_homework_pkey PRIMARY KEY (id);


--
-- Name: student_parent_links student_parent_links_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.student_parent_links
    ADD CONSTRAINT student_parent_links_pkey PRIMARY KEY (id);


--
-- Name: student_transport_assignments student_transport_assignments_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.student_transport_assignments
    ADD CONSTRAINT student_transport_assignments_pkey PRIMARY KEY (id);


--
-- Name: student_trips student_trips_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.student_trips
    ADD CONSTRAINT student_trips_pkey PRIMARY KEY (id);


--
-- Name: students students_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.students
    ADD CONSTRAINT students_pkey PRIMARY KEY (id);


--
-- Name: students students_user_id_key; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.students
    ADD CONSTRAINT students_user_id_key UNIQUE (user_id);


--
-- Name: subject_categories subject_categories_name_key; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.subject_categories
    ADD CONSTRAINT subject_categories_name_key UNIQUE (name);


--
-- Name: subject_categories subject_categories_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.subject_categories
    ADD CONSTRAINT subject_categories_pkey PRIMARY KEY (id);


--
-- Name: subjects subjects_name_key; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.subjects
    ADD CONSTRAINT subjects_name_key UNIQUE (name);


--
-- Name: subjects subjects_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.subjects
    ADD CONSTRAINT subjects_pkey PRIMARY KEY (id);


--
-- Name: timetable_slots timetable_slots_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.timetable_slots
    ADD CONSTRAINT timetable_slots_pkey PRIMARY KEY (id);


--
-- Name: timetable_subject_options timetable_subject_options_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.timetable_subject_options
    ADD CONSTRAINT timetable_subject_options_pkey PRIMARY KEY (id);


--
-- Name: timetables timetables_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.timetables
    ADD CONSTRAINT timetables_pkey PRIMARY KEY (id);


--
-- Name: timetables timetables_section_id_key; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.timetables
    ADD CONSTRAINT timetables_section_id_key UNIQUE (section_id);


--
-- Name: trips trips_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.trips
    ADD CONSTRAINT trips_pkey PRIMARY KEY (id);


--
-- Name: expense_settings uq_expense_setting_key; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.expense_settings
    ADD CONSTRAINT uq_expense_setting_key UNIQUE (setting_key);


--
-- Name: expense_transactions uq_expense_transaction_idempotency; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.expense_transactions
    ADD CONSTRAINT uq_expense_transaction_idempotency UNIQUE (idempotency_key);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: vehicles vehicles_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.vehicles
    ADD CONSTRAINT vehicles_pkey PRIMARY KEY (id);


--
-- Name: vehicles vehicles_registration_number_key; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.vehicles
    ADD CONSTRAINT vehicles_registration_number_key UNIQUE (registration_number);


--
-- Name: academic_years_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX academic_years_id_idx ON test_tenant_schema.academic_years USING btree (id);


--
-- Name: certificate_types_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX certificate_types_id_idx ON test_tenant_schema.certificate_types USING btree (id);


--
-- Name: class_subject_mappings_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX class_subject_mappings_id_idx ON test_tenant_schema.class_subject_mappings USING btree (id);


--
-- Name: classes_academic_year_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX classes_academic_year_id_idx ON test_tenant_schema.classes USING btree (academic_year_id);


--
-- Name: classes_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX classes_id_idx ON test_tenant_schema.classes USING btree (id);


--
-- Name: designations_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX designations_id_idx ON test_tenant_schema.designations USING btree (id);


--
-- Name: fee_categories_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX fee_categories_id_idx ON test_tenant_schema.fee_categories USING btree (id);


--
-- Name: fee_class_map_term_amounts_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX fee_class_map_term_amounts_id_idx ON test_tenant_schema.fee_class_map_term_amounts USING btree (id);


--
-- Name: fee_class_mappings_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX fee_class_mappings_id_idx ON test_tenant_schema.fee_class_mappings USING btree (id);


--
-- Name: fee_term_dates_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX fee_term_dates_id_idx ON test_tenant_schema.fee_term_dates USING btree (id);


--
-- Name: fee_term_dates_term_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX fee_term_dates_term_id_idx ON test_tenant_schema.fee_term_dates USING btree (term_id);


--
-- Name: fee_terms_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX fee_terms_id_idx ON test_tenant_schema.fee_terms USING btree (id);


--
-- Name: fee_types_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX fee_types_id_idx ON test_tenant_schema.fee_types USING btree (id);


--
-- Name: holidays_academic_year_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX holidays_academic_year_id_idx ON test_tenant_schema.holidays USING btree (academic_year_id);


--
-- Name: holidays_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX holidays_id_idx ON test_tenant_schema.holidays USING btree (id);


--
-- Name: idx_fee_trans_academic_year; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX idx_fee_trans_academic_year ON test_tenant_schema.fee_transactions USING btree (academic_year_id, transaction_date);


--
-- Name: idx_fee_trans_item_fee_type; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX idx_fee_trans_item_fee_type ON test_tenant_schema.fee_transaction_items USING btree (fee_type_id, fee_term_id);


--
-- Name: idx_fee_trans_item_transaction; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX idx_fee_trans_item_transaction ON test_tenant_schema.fee_transaction_items USING btree (fee_transaction_id);


--
-- Name: idx_fee_trans_status_method; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX idx_fee_trans_status_method ON test_tenant_schema.fee_transactions USING btree (status, payment_method);


--
-- Name: idx_fee_trans_student_date; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX idx_fee_trans_student_date ON test_tenant_schema.fee_transactions USING btree (student_id, transaction_date);


--
-- Name: ix_expense_attachments_department_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_attachments_department_id ON test_tenant_schema.expense_attachments USING btree (department_id);


--
-- Name: ix_expense_attachments_file_hash_sha256; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_attachments_file_hash_sha256 ON test_tenant_schema.expense_attachments USING btree (file_hash_sha256);


--
-- Name: ix_expense_attachments_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_attachments_id ON test_tenant_schema.expense_attachments USING btree (id);


--
-- Name: ix_expense_attachments_org_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_attachments_org_id ON test_tenant_schema.expense_attachments USING btree (org_id);


--
-- Name: ix_expense_attachments_transaction_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_attachments_transaction_id ON test_tenant_schema.expense_attachments USING btree (transaction_id);


--
-- Name: ix_expense_attachments_uploaded_by_user_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_attachments_uploaded_by_user_id ON test_tenant_schema.expense_attachments USING btree (uploaded_by_user_id);


--
-- Name: ix_expense_audit_logs_action; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_audit_logs_action ON test_tenant_schema.expense_audit_logs USING btree (action);


--
-- Name: ix_expense_audit_logs_action_category; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_audit_logs_action_category ON test_tenant_schema.expense_audit_logs USING btree (action_category);


--
-- Name: ix_expense_audit_logs_actor_role; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_audit_logs_actor_role ON test_tenant_schema.expense_audit_logs USING btree (actor_role);


--
-- Name: ix_expense_audit_logs_actor_user_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_audit_logs_actor_user_id ON test_tenant_schema.expense_audit_logs USING btree (actor_user_id);


--
-- Name: ix_expense_audit_logs_created_at; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_audit_logs_created_at ON test_tenant_schema.expense_audit_logs USING btree (created_at);


--
-- Name: ix_expense_audit_logs_department_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_audit_logs_department_id ON test_tenant_schema.expense_audit_logs USING btree (department_id);


--
-- Name: ix_expense_audit_logs_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_audit_logs_id ON test_tenant_schema.expense_audit_logs USING btree (id);


--
-- Name: ix_expense_audit_logs_org_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_audit_logs_org_id ON test_tenant_schema.expense_audit_logs USING btree (org_id);


--
-- Name: ix_expense_audit_logs_transaction_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_audit_logs_transaction_id ON test_tenant_schema.expense_audit_logs USING btree (transaction_id);


--
-- Name: ix_expense_categories_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_categories_id ON test_tenant_schema.expense_categories USING btree (id);


--
-- Name: ix_expense_categories_org_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_categories_org_id ON test_tenant_schema.expense_categories USING btree (org_id);


--
-- Name: ix_expense_settings_created_by_user_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_settings_created_by_user_id ON test_tenant_schema.expense_settings USING btree (created_by_user_id);


--
-- Name: ix_expense_settings_department_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_settings_department_id ON test_tenant_schema.expense_settings USING btree (department_id);


--
-- Name: ix_expense_settings_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_settings_id ON test_tenant_schema.expense_settings USING btree (id);


--
-- Name: ix_expense_settings_org_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_settings_org_id ON test_tenant_schema.expense_settings USING btree (org_id);


--
-- Name: ix_expense_settings_setting_category; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_settings_setting_category ON test_tenant_schema.expense_settings USING btree (setting_category);


--
-- Name: ix_expense_settings_setting_key; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_settings_setting_key ON test_tenant_schema.expense_settings USING btree (setting_key);


--
-- Name: ix_expense_transaction_items_created_by_user_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_transaction_items_created_by_user_id ON test_tenant_schema.expense_transaction_items USING btree (created_by_user_id);


--
-- Name: ix_expense_transaction_items_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_transaction_items_id ON test_tenant_schema.expense_transaction_items USING btree (id);


--
-- Name: ix_expense_transaction_items_org_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_transaction_items_org_id ON test_tenant_schema.expense_transaction_items USING btree (org_id);


--
-- Name: ix_expense_transaction_items_transaction_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_transaction_items_transaction_id ON test_tenant_schema.expense_transaction_items USING btree (transaction_id);


--
-- Name: ix_expense_transactions_created_by_user_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_transactions_created_by_user_id ON test_tenant_schema.expense_transactions USING btree (created_by_user_id);


--
-- Name: ix_expense_transactions_department_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_transactions_department_id ON test_tenant_schema.expense_transactions USING btree (department_id);


--
-- Name: ix_expense_transactions_expense_type_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_transactions_expense_type_id ON test_tenant_schema.expense_transactions USING btree (expense_type_id);


--
-- Name: ix_expense_transactions_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_transactions_id ON test_tenant_schema.expense_transactions USING btree (id);


--
-- Name: ix_expense_transactions_org_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_transactions_org_id ON test_tenant_schema.expense_transactions USING btree (org_id);


--
-- Name: ix_expense_transactions_status; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_transactions_status ON test_tenant_schema.expense_transactions USING btree (status);


--
-- Name: ix_expense_transactions_transaction_date; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_transactions_transaction_date ON test_tenant_schema.expense_transactions USING btree (transaction_date);


--
-- Name: ix_expense_transactions_vendor_name; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_transactions_vendor_name ON test_tenant_schema.expense_transactions USING btree (vendor_name);


--
-- Name: ix_expense_types_category_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_types_category_id ON test_tenant_schema.expense_types USING btree (category_id);


--
-- Name: ix_expense_types_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_types_id ON test_tenant_schema.expense_types USING btree (id);


--
-- Name: ix_expense_types_org_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_types_org_id ON test_tenant_schema.expense_types USING btree (org_id);


--
-- Name: ix_fee_receipts_fee_transaction_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_fee_receipts_fee_transaction_id ON test_tenant_schema.fee_receipts USING btree (fee_transaction_id);


--
-- Name: ix_fee_receipts_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX ix_fee_receipts_id ON test_tenant_schema.fee_receipts USING btree (id);


--
-- Name: ix_fee_receipts_receipt_number; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX ix_fee_receipts_receipt_number ON test_tenant_schema.fee_receipts USING btree (receipt_number);


--
-- Name: ix_fee_refunds_fee_transaction_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_fee_refunds_fee_transaction_id ON test_tenant_schema.fee_refunds USING btree (fee_transaction_id);


--
-- Name: ix_fee_refunds_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX ix_fee_refunds_id ON test_tenant_schema.fee_refunds USING btree (id);


--
-- Name: ix_fee_refunds_refund_number; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX ix_fee_refunds_refund_number ON test_tenant_schema.fee_refunds USING btree (refund_number);


--
-- Name: ix_fee_refunds_student_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_fee_refunds_student_id ON test_tenant_schema.fee_refunds USING btree (student_id);


--
-- Name: ix_fee_transaction_items_fee_term_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_fee_transaction_items_fee_term_id ON test_tenant_schema.fee_transaction_items USING btree (fee_term_id);


--
-- Name: ix_fee_transaction_items_fee_transaction_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_fee_transaction_items_fee_transaction_id ON test_tenant_schema.fee_transaction_items USING btree (fee_transaction_id);


--
-- Name: ix_fee_transaction_items_fee_type_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_fee_transaction_items_fee_type_id ON test_tenant_schema.fee_transaction_items USING btree (fee_type_id);


--
-- Name: ix_fee_transaction_items_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX ix_fee_transaction_items_id ON test_tenant_schema.fee_transaction_items USING btree (id);


--
-- Name: ix_fee_transactions_academic_year_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_fee_transactions_academic_year_id ON test_tenant_schema.fee_transactions USING btree (academic_year_id);


--
-- Name: ix_fee_transactions_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX ix_fee_transactions_id ON test_tenant_schema.fee_transactions USING btree (id);


--
-- Name: ix_fee_transactions_student_admission_num; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_fee_transactions_student_admission_num ON test_tenant_schema.fee_transactions USING btree (student_admission_num);


--
-- Name: ix_fee_transactions_student_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_fee_transactions_student_id ON test_tenant_schema.fee_transactions USING btree (student_id);


--
-- Name: ix_fee_transactions_transaction_number; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX ix_fee_transactions_transaction_number ON test_tenant_schema.fee_transactions USING btree (transaction_number);


--
-- Name: menus_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX menus_id_idx ON test_tenant_schema.menus USING btree (id);


--
-- Name: parents_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX parents_id_idx ON test_tenant_schema.parents USING btree (id);


--
-- Name: resource_permissions_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX resource_permissions_id_idx ON test_tenant_schema.resource_permissions USING btree (id);


--
-- Name: role_inheritance_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX role_inheritance_id_idx ON test_tenant_schema.role_inheritance USING btree (id);


--
-- Name: role_menu_permissions_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX role_menu_permissions_id_idx ON test_tenant_schema.role_menu_permissions USING btree (id);


--
-- Name: roles_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX roles_id_idx ON test_tenant_schema.roles USING btree (id);


--
-- Name: route_stops_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX route_stops_id_idx ON test_tenant_schema.route_stops USING btree (id);


--
-- Name: routes_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX routes_id_idx ON test_tenant_schema.routes USING btree (id);


--
-- Name: sections_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX sections_id_idx ON test_tenant_schema.sections USING btree (id);


--
-- Name: slot_times_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX slot_times_id_idx ON test_tenant_schema.slot_times USING btree (id);


--
-- Name: staff_attendance_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX staff_attendance_id_idx ON test_tenant_schema.staff_attendance USING btree (id);


--
-- Name: staff_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX staff_id_idx ON test_tenant_schema.staff USING btree (id);


--
-- Name: student_admissions_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX student_admissions_id_idx ON test_tenant_schema.student_admissions USING btree (id);


--
-- Name: student_attendance_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX student_attendance_id_idx ON test_tenant_schema.student_attendance USING btree (id);


--
-- Name: student_certificates_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX student_certificates_id_idx ON test_tenant_schema.student_certificates USING btree (id);


--
-- Name: student_documents_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX student_documents_id_idx ON test_tenant_schema.student_documents USING btree (id);


--
-- Name: student_homework_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX student_homework_id_idx ON test_tenant_schema.student_homework USING btree (id);


--
-- Name: student_parent_links_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX student_parent_links_id_idx ON test_tenant_schema.student_parent_links USING btree (id);


--
-- Name: student_transport_assignments_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX student_transport_assignments_id_idx ON test_tenant_schema.student_transport_assignments USING btree (id);


--
-- Name: student_trips_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX student_trips_id_idx ON test_tenant_schema.student_trips USING btree (id);


--
-- Name: students_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX students_id_idx ON test_tenant_schema.students USING btree (id);


--
-- Name: subject_categories_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX subject_categories_id_idx ON test_tenant_schema.subject_categories USING btree (id);


--
-- Name: subjects_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX subjects_id_idx ON test_tenant_schema.subjects USING btree (id);


--
-- Name: timetable_slots_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX timetable_slots_id_idx ON test_tenant_schema.timetable_slots USING btree (id);


--
-- Name: timetable_subject_options_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX timetable_subject_options_id_idx ON test_tenant_schema.timetable_subject_options USING btree (id);


--
-- Name: timetables_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX timetables_id_idx ON test_tenant_schema.timetables USING btree (id);


--
-- Name: trips_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX trips_id_idx ON test_tenant_schema.trips USING btree (id);


--
-- Name: users_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX users_id_idx ON test_tenant_schema.users USING btree (id);


--
-- Name: vehicles_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX vehicles_id_idx ON test_tenant_schema.vehicles USING btree (id);


--
-- Name: expense_attachments expense_attachments_transaction_id_fkey; Type: FK CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.expense_attachments
    ADD CONSTRAINT expense_attachments_transaction_id_fkey FOREIGN KEY (transaction_id) REFERENCES test_tenant_schema.expense_transactions(id);


--
-- Name: expense_audit_logs expense_audit_logs_transaction_id_fkey; Type: FK CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.expense_audit_logs
    ADD CONSTRAINT expense_audit_logs_transaction_id_fkey FOREIGN KEY (transaction_id) REFERENCES test_tenant_schema.expense_transactions(id);


--
-- Name: expense_transaction_items expense_transaction_items_transaction_id_fkey; Type: FK CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.expense_transaction_items
    ADD CONSTRAINT expense_transaction_items_transaction_id_fkey FOREIGN KEY (transaction_id) REFERENCES test_tenant_schema.expense_transactions(id);


--
-- Name: expense_transactions expense_transactions_expense_type_id_fkey; Type: FK CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.expense_transactions
    ADD CONSTRAINT expense_transactions_expense_type_id_fkey FOREIGN KEY (expense_type_id) REFERENCES test_tenant_schema.expense_types(id);


--
-- Name: expense_types expense_types_category_id_fkey; Type: FK CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.expense_types
    ADD CONSTRAINT expense_types_category_id_fkey FOREIGN KEY (category_id) REFERENCES test_tenant_schema.expense_categories(id);


--
-- Name: fee_receipts fee_receipts_fee_transaction_id_fkey; Type: FK CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.fee_receipts
    ADD CONSTRAINT fee_receipts_fee_transaction_id_fkey FOREIGN KEY (fee_transaction_id) REFERENCES test_tenant_schema.fee_transactions(id);


--
-- Name: fee_refunds fee_refunds_fee_transaction_id_fkey; Type: FK CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.fee_refunds
    ADD CONSTRAINT fee_refunds_fee_transaction_id_fkey FOREIGN KEY (fee_transaction_id) REFERENCES test_tenant_schema.fee_transactions(id);


--
-- Name: fee_transaction_items fee_transaction_items_fee_transaction_id_fkey; Type: FK CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.fee_transaction_items
    ADD CONSTRAINT fee_transaction_items_fee_transaction_id_fkey FOREIGN KEY (fee_transaction_id) REFERENCES test_tenant_schema.fee_transactions(id);


--
-- PostgreSQL database dump complete
--

