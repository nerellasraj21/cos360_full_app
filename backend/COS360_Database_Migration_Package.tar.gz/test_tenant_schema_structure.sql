--
-- PostgreSQL database dump
--

-- Dumped from database version 17.5
-- Dumped by pg_dump version 17.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: test_tenant_schema; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA test_tenant_schema;


ALTER SCHEMA test_tenant_schema OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: academic_years; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.academic_years (
    id uuid NOT NULL,
    title character varying(50) NOT NULL,
    is_active boolean,
    start_date date NOT NULL,
    end_date date NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE test_tenant_schema.academic_years OWNER TO postgres;

--
-- Name: alembic_version; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE test_tenant_schema.alembic_version OWNER TO postgres;

--
-- Name: certificate_types; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.certificate_types (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(100) NOT NULL,
    description character varying(255)
);


ALTER TABLE test_tenant_schema.certificate_types OWNER TO postgres;

--
-- Name: class_subject_mappings; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.class_subject_mappings (
    id uuid NOT NULL,
    class_id uuid NOT NULL,
    subject_id uuid NOT NULL,
    is_active boolean,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    academic_year_id uuid NOT NULL,
    exclude_marks boolean DEFAULT false NOT NULL,
    "order" integer
);


ALTER TABLE test_tenant_schema.class_subject_mappings OWNER TO postgres;

--
-- Name: classes; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.classes (
    id uuid NOT NULL,
    name character varying(50) NOT NULL,
    description character varying(100),
    is_active boolean,
    short_code character varying(10),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    academic_year_id uuid NOT NULL
);


ALTER TABLE test_tenant_schema.classes OWNER TO postgres;

--
-- Name: designations; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.designations (
    id uuid NOT NULL,
    title character varying(100) NOT NULL
);


ALTER TABLE test_tenant_schema.designations OWNER TO postgres;

--
-- Name: expense_attachments; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.expense_attachments (
    id uuid NOT NULL,
    transaction_id uuid NOT NULL,
    original_filename character varying(255) NOT NULL,
    stored_filename character varying(255) NOT NULL,
    file_path character varying(500) NOT NULL,
    file_size bigint NOT NULL,
    mime_type character varying(100) NOT NULL,
    file_extension character varying(10) NOT NULL,
    file_hash_sha256 character varying(64) NOT NULL,
    virus_scan_status character varying(20) NOT NULL,
    virus_scan_result text,
    virus_scanned_at timestamp without time zone,
    is_public boolean,
    is_encrypted boolean,
    encryption_key_id character varying(100),
    document_type character varying(50) NOT NULL,
    is_verified boolean,
    verified_by_user_id uuid,
    verified_at timestamp without time zone,
    verification_notes text,
    retention_period_months integer NOT NULL,
    is_archived boolean,
    archived_at timestamp without time zone,
    can_be_deleted boolean,
    department_id uuid,
    uploaded_by_user_id uuid NOT NULL,
    uploaded_by_role character varying(50) NOT NULL,
    uploaded_at timestamp without time zone DEFAULT now() NOT NULL,
    last_accessed_at timestamp without time zone,
    access_count integer NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    org_id uuid NOT NULL
);


ALTER TABLE test_tenant_schema.expense_attachments OWNER TO postgres;

--
-- Name: expense_audit_logs; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.expense_audit_logs (
    id uuid NOT NULL,
    transaction_id uuid NOT NULL,
    action character varying(50) NOT NULL,
    action_category character varying(30) NOT NULL,
    field_name character varying(100),
    old_value text,
    new_value text,
    full_record_before json,
    full_record_after json,
    action_reason character varying(500),
    action_notes text,
    request_ip_address character varying(45),
    request_user_agent character varying(500),
    request_session_id character varying(100),
    api_endpoint character varying(200),
    http_method character varying(10),
    request_id character varying(100),
    workflow_stage character varying(50),
    compliance_flags json,
    department_id uuid,
    actor_user_id uuid NOT NULL,
    actor_role character varying(50) NOT NULL,
    actor_username character varying(100) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    org_id uuid NOT NULL
);


ALTER TABLE test_tenant_schema.expense_audit_logs OWNER TO postgres;

--
-- Name: expense_categories; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.expense_categories (
    id uuid NOT NULL,
    name character varying(100) NOT NULL,
    description character varying(300),
    is_active boolean,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    org_id uuid NOT NULL
);


ALTER TABLE test_tenant_schema.expense_categories OWNER TO postgres;

--
-- Name: expense_settings; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.expense_settings (
    id uuid NOT NULL,
    setting_key character varying(100) NOT NULL,
    setting_name character varying(200) NOT NULL,
    setting_description text,
    setting_category character varying(50) NOT NULL,
    string_value character varying(500),
    numeric_value numeric(15,2),
    integer_value integer,
    boolean_value boolean,
    "json_value" json,
    default_value text,
    is_system_setting boolean,
    is_user_configurable boolean,
    validation_rules json,
    allowed_values json,
    requires_approval boolean,
    approval_threshold numeric(10,2),
    department_id uuid,
    applies_to_all_departments boolean,
    is_audit_required boolean,
    is_sensitive boolean,
    compliance_level character varying(20),
    version integer NOT NULL,
    is_active boolean,
    effective_from timestamp without time zone,
    effective_until timestamp without time zone,
    created_by_user_id uuid NOT NULL,
    created_by_role character varying(50) NOT NULL,
    last_modified_by_user_id uuid,
    last_modified_by_role character varying(50),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    org_id uuid NOT NULL
);


ALTER TABLE test_tenant_schema.expense_settings OWNER TO postgres;

--
-- Name: expense_transaction_items; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.expense_transaction_items (
    id uuid NOT NULL,
    transaction_id uuid NOT NULL,
    item_name character varying(200) NOT NULL,
    item_description text,
    unit_price numeric(10,2) NOT NULL,
    quantity numeric(8,2) NOT NULL,
    total_price numeric(10,2) NOT NULL,
    item_category character varying(100),
    tax_rate numeric(5,2),
    tax_amount numeric(10,2),
    discount_rate numeric(5,2),
    discount_amount numeric(10,2),
    final_amount numeric(10,2) NOT NULL,
    vendor_item_code character varying(100),
    vendor_item_reference character varying(100),
    created_by_user_id uuid NOT NULL,
    created_by_role character varying(50) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    org_id uuid NOT NULL
);


ALTER TABLE test_tenant_schema.expense_transaction_items OWNER TO postgres;

--
-- Name: expense_transactions; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.expense_transactions (
    id uuid NOT NULL,
    expense_type_id uuid NOT NULL,
    amount numeric(10,2) NOT NULL,
    transaction_date date NOT NULL,
    description character varying(500) NOT NULL,
    reference_number character varying(100),
    idempotency_key character varying(100) NOT NULL,
    payment_method character varying(20) NOT NULL,
    vendor_name character varying(200),
    status character varying(20) NOT NULL,
    requires_approval boolean,
    requires_approval_override boolean,
    approved_by_user_id uuid,
    approved_by_role character varying(50),
    approved_at timestamp without time zone,
    approval_comment character varying(500),
    department_id uuid,
    version integer NOT NULL,
    created_by_user_id uuid NOT NULL,
    created_by_role character varying(50) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    org_id uuid NOT NULL
);


ALTER TABLE test_tenant_schema.expense_transactions OWNER TO postgres;

--
-- Name: expense_types; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.expense_types (
    id uuid NOT NULL,
    name character varying(100) NOT NULL,
    category_id uuid NOT NULL,
    description character varying(300),
    is_active boolean,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    org_id uuid NOT NULL
);


ALTER TABLE test_tenant_schema.expense_types OWNER TO postgres;

--
-- Name: fee_categories; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.fee_categories (
    id uuid NOT NULL,
    category_name character varying(100) NOT NULL,
    category_status character varying(20) NOT NULL,
    academic_year_id uuid NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE test_tenant_schema.fee_categories OWNER TO postgres;

--
-- Name: fee_class_map_term_amounts; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.fee_class_map_term_amounts (
    id uuid NOT NULL,
    fee_class_mapping_id uuid NOT NULL,
    term_id uuid NOT NULL,
    term_amount numeric(10,2) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE test_tenant_schema.fee_class_map_term_amounts OWNER TO postgres;

--
-- Name: fee_class_mappings; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.fee_class_mappings (
    id uuid NOT NULL,
    class_id uuid NOT NULL,
    fee_type_id uuid NOT NULL,
    total_fee numeric(10,2) NOT NULL,
    academic_year_id uuid NOT NULL,
    all_by_default boolean NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE test_tenant_schema.fee_class_mappings OWNER TO postgres;

--
-- Name: fee_receipts; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.fee_receipts (
    id uuid NOT NULL,
    receipt_number character varying(50) NOT NULL,
    fee_transaction_id uuid NOT NULL,
    student_name character varying(200) NOT NULL,
    student_admission_num character varying(50) NOT NULL,
    class_section character varying(100) NOT NULL,
    academic_year character varying(50) NOT NULL,
    content_hash character varying(64) NOT NULL,
    pdf_file_path character varying(500),
    is_reprinted boolean NOT NULL,
    reprint_count character varying DEFAULT '0'::character varying NOT NULL,
    generated_by_user_id uuid NOT NULL,
    remarks text,
    generated_at timestamp without time zone DEFAULT now() NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE test_tenant_schema.fee_receipts OWNER TO postgres;

--
-- Name: fee_refunds; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.fee_refunds (
    id uuid NOT NULL,
    refund_number character varying(50) NOT NULL,
    fee_transaction_id uuid NOT NULL,
    student_id uuid NOT NULL,
    student_admission_num character varying(50) NOT NULL,
    academic_year_id uuid NOT NULL,
    refund_amount numeric(10,2) NOT NULL,
    refund_reason character varying(20) NOT NULL,
    detailed_reason text,
    status character varying(20) NOT NULL,
    requested_by_user_id uuid NOT NULL,
    approved_by_user_id uuid,
    processed_by_user_id uuid,
    refund_method character varying(20),
    refund_reference character varying(100),
    approval_remarks text,
    processing_remarks text,
    requested_date timestamp without time zone DEFAULT now() NOT NULL,
    approved_date timestamp without time zone,
    processed_date timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE test_tenant_schema.fee_refunds OWNER TO postgres;

--
-- Name: fee_term_dates; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.fee_term_dates (
    id uuid NOT NULL,
    term_id uuid NOT NULL,
    fee_term_date date NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE test_tenant_schema.fee_term_dates OWNER TO postgres;

--
-- Name: fee_terms; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.fee_terms (
    id uuid NOT NULL,
    term_name character varying(50) NOT NULL,
    term_status character varying(20) NOT NULL,
    number_of_terms integer NOT NULL,
    academic_year_id uuid NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE test_tenant_schema.fee_terms OWNER TO postgres;

--
-- Name: fee_transaction_items; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.fee_transaction_items (
    id uuid NOT NULL,
    fee_transaction_id uuid NOT NULL,
    fee_type_id uuid NOT NULL,
    fee_term_id uuid NOT NULL,
    amount_due numeric(10,2) NOT NULL,
    amount_paid numeric(10,2) NOT NULL,
    description character varying(200),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE test_tenant_schema.fee_transaction_items OWNER TO postgres;

--
-- Name: fee_transactions; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.fee_transactions (
    id uuid NOT NULL,
    transaction_number character varying(50) NOT NULL,
    student_id uuid NOT NULL,
    student_admission_num character varying(50) NOT NULL,
    academic_year_id uuid NOT NULL,
    total_amount numeric(10,2) NOT NULL,
    payment_method character varying(20) NOT NULL,
    status character varying(20) NOT NULL,
    upi_reference character varying(100),
    upi_app_name character varying(50),
    cheque_number character varying(50),
    cheque_date timestamp without time zone,
    cheque_bank character varying(100),
    cheque_status character varying(20),
    bank_reference character varying(100),
    bank_name character varying(100),
    collected_by_user_id uuid NOT NULL,
    approved_by_user_id uuid,
    receipt_generated boolean NOT NULL,
    receipt_hash character varying(64),
    remarks text,
    transaction_date timestamp without time zone DEFAULT now() NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE test_tenant_schema.fee_transactions OWNER TO postgres;

--
-- Name: fee_types; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.fee_types (
    id uuid NOT NULL,
    type_name character varying(100) NOT NULL,
    fee_category_id uuid NOT NULL,
    fee_status character varying(20) NOT NULL,
    fee_term_id uuid NOT NULL,
    academic_year_id uuid NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE test_tenant_schema.fee_types OWNER TO postgres;

--
-- Name: holidays; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.holidays (
    id uuid NOT NULL,
    name character varying(50) NOT NULL,
    description character varying(100),
    start_date date NOT NULL,
    end_date date NOT NULL,
    is_active boolean,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    academic_year_id uuid NOT NULL
);


ALTER TABLE test_tenant_schema.holidays OWNER TO postgres;

--
-- Name: menus; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.menus (
    id uuid NOT NULL,
    name character varying(50) NOT NULL,
    url character varying(100),
    level character varying(2) NOT NULL,
    parent_id uuid,
    display_order integer NOT NULL
);


ALTER TABLE test_tenant_schema.menus OWNER TO postgres;

--
-- Name: parents; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.parents (
    id uuid NOT NULL,
    name character varying(100) NOT NULL,
    email character varying(100),
    phone character varying(15),
    occupation character varying(100),
    aadhar_number character varying(12),
    gender character varying(10),
    relation_to_student character varying(20),
    user_id uuid NOT NULL
);


ALTER TABLE test_tenant_schema.parents OWNER TO postgres;

--
-- Name: resource_permissions; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.resource_permissions (
    id uuid NOT NULL,
    role_id uuid NOT NULL,
    resource character varying(50) NOT NULL,
    action character varying(30) NOT NULL,
    is_granted boolean NOT NULL
);


ALTER TABLE test_tenant_schema.resource_permissions OWNER TO postgres;

--
-- Name: role_inheritance; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.role_inheritance (
    id uuid NOT NULL,
    tenant_role_id uuid NOT NULL,
    public_role_template_id integer NOT NULL,
    is_active boolean
);


ALTER TABLE test_tenant_schema.role_inheritance OWNER TO postgres;

--
-- Name: role_menu_permissions; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.role_menu_permissions (
    id uuid NOT NULL,
    role_id uuid NOT NULL,
    menu_id uuid NOT NULL,
    can_view boolean,
    can_edit boolean
);


ALTER TABLE test_tenant_schema.role_menu_permissions OWNER TO postgres;

--
-- Name: roles; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.roles (
    id uuid NOT NULL,
    name character varying(50) NOT NULL,
    description character varying(100),
    is_system_role boolean,
    is_custom_role boolean
);


ALTER TABLE test_tenant_schema.roles OWNER TO postgres;

--
-- Name: route_stops; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.route_stops (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    route_id uuid,
    name character varying NOT NULL,
    number integer,
    reaching_time time without time zone,
    fees integer,
    is_active boolean
);


ALTER TABLE test_tenant_schema.route_stops OWNER TO postgres;

--
-- Name: routes; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.routes (
    id uuid NOT NULL,
    route_name character varying NOT NULL,
    starting_stop character varying NOT NULL,
    ending_stop character varying NOT NULL,
    number_of_stops integer,
    route_type character varying,
    trip_type character varying,
    start_time time without time zone,
    end_time time without time zone,
    is_active boolean
);


ALTER TABLE test_tenant_schema.routes OWNER TO postgres;

--
-- Name: sections; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.sections (
    id uuid NOT NULL,
    name character varying(50) NOT NULL,
    description character varying(50),
    is_active boolean,
    class_id uuid NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE test_tenant_schema.sections OWNER TO postgres;

--
-- Name: slot_times; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.slot_times (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    section_id uuid NOT NULL,
    label character varying,
    start_time time without time zone NOT NULL,
    end_time time without time zone NOT NULL
);


ALTER TABLE test_tenant_schema.slot_times OWNER TO postgres;

--
-- Name: staff; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.staff (
    id uuid NOT NULL,
    first_name character varying(100) NOT NULL,
    last_name character varying(100),
    email character varying(100),
    phone character varying(15),
    gender cos360_main.genderenum,
    date_of_birth date,
    joining_date date NOT NULL,
    qualification character varying(100),
    experience_years integer,
    address character varying(255),
    designation_id uuid,
    department character varying(100),
    is_active boolean,
    user_id uuid NOT NULL
);


ALTER TABLE test_tenant_schema.staff OWNER TO postgres;

--
-- Name: staff_attendance; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.staff_attendance (
    id uuid NOT NULL,
    staff_id uuid NOT NULL,
    date date NOT NULL,
    status character varying(10) NOT NULL
);


ALTER TABLE test_tenant_schema.staff_attendance OWNER TO postgres;

--
-- Name: student_admissions; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.student_admissions (
    id uuid NOT NULL,
    student_id uuid NOT NULL,
    admission_number character varying(50),
    admission_date date NOT NULL,
    academic_year_id uuid,
    admitted_academic_year_id uuid,
    admitted_class_id uuid,
    admitted_section_id uuid,
    current_class_id uuid,
    current_section_id uuid,
    address_line1 character varying(255),
    address_line2 character varying(255),
    city character varying(100),
    state character varying(100),
    is_previous_school boolean,
    previous_school_name character varying(255),
    previous_class character varying(50),
    previous_school_remark character varying(100)
);


ALTER TABLE test_tenant_schema.student_admissions OWNER TO postgres;

--
-- Name: student_attendance; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.student_attendance (
    id uuid NOT NULL,
    student_id uuid NOT NULL,
    date date NOT NULL,
    status character varying(20) NOT NULL,
    remarks text
);


ALTER TABLE test_tenant_schema.student_attendance OWNER TO postgres;

--
-- Name: student_certificates; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.student_certificates (
    id uuid NOT NULL,
    student_id uuid NOT NULL,
    certificate_type_id uuid,
    issue_date date,
    file_path character varying,
    remarks character varying(255)
);


ALTER TABLE test_tenant_schema.student_certificates OWNER TO postgres;

--
-- Name: student_documents; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.student_documents (
    id uuid NOT NULL,
    student_id uuid NOT NULL,
    document_type character varying NOT NULL,
    file_path character varying NOT NULL,
    upload_date timestamp without time zone
);


ALTER TABLE test_tenant_schema.student_documents OWNER TO postgres;

--
-- Name: student_homework; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.student_homework (
    id uuid NOT NULL,
    student_id uuid NOT NULL,
    subject_id uuid,
    description text,
    due_date date,
    submission_status character varying(20)
);


ALTER TABLE test_tenant_schema.student_homework OWNER TO postgres;

--
-- Name: student_parent_links; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.student_parent_links (
    id uuid NOT NULL,
    student_id uuid,
    parent_id uuid
);


ALTER TABLE test_tenant_schema.student_parent_links OWNER TO postgres;

--
-- Name: student_transport_assignments; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.student_transport_assignments (
    id uuid NOT NULL,
    student_id uuid NOT NULL,
    trip_id uuid NOT NULL,
    stop_id uuid NOT NULL,
    fee_per_term double precision NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE test_tenant_schema.student_transport_assignments OWNER TO postgres;

--
-- Name: student_trips; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.student_trips (
    id uuid NOT NULL,
    trip_id uuid,
    student_id uuid,
    stop_id uuid,
    fee_term_id uuid,
    fee_per_term integer,
    is_active boolean
);


ALTER TABLE test_tenant_schema.student_trips OWNER TO postgres;

--
-- Name: students; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.students (
    id uuid NOT NULL,
    first_name character varying(100) NOT NULL,
    last_name character varying(100) NOT NULL,
    date_of_birth date NOT NULL,
    gender character varying(10),
    is_primary character varying(20),
    aadhar_number character varying(12),
    apaar_number character varying(12),
    caste character varying(100),
    sub_caste character varying(100),
    community character varying(100),
    nationality character varying(100),
    mother_tongue character varying(100),
    identification_marks character varying(100),
    user_id uuid NOT NULL
);


ALTER TABLE test_tenant_schema.students OWNER TO postgres;

--
-- Name: subject_categories; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.subject_categories (
    id uuid NOT NULL,
    name character varying(100) NOT NULL
);


ALTER TABLE test_tenant_schema.subject_categories OWNER TO postgres;

--
-- Name: subjects; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.subjects (
    id uuid NOT NULL,
    name character varying(50) NOT NULL,
    category_id uuid,
    is_active boolean,
    short_code character varying(10),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    academic_year_id uuid NOT NULL
);


ALTER TABLE test_tenant_schema.subjects OWNER TO postgres;

--
-- Name: timetable_slots; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.timetable_slots (
    id uuid NOT NULL,
    timetable_id uuid,
    day character varying NOT NULL,
    slot_time_id uuid,
    is_break boolean,
    break_label character varying
);


ALTER TABLE test_tenant_schema.timetable_slots OWNER TO postgres;

--
-- Name: timetable_subject_options; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.timetable_subject_options (
    id uuid NOT NULL,
    slot_id uuid NOT NULL,
    subject_id uuid
);


ALTER TABLE test_tenant_schema.timetable_subject_options OWNER TO postgres;

--
-- Name: timetables; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.timetables (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    section_id uuid NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE test_tenant_schema.timetables OWNER TO postgres;

--
-- Name: trips; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.trips (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    vehicle_id uuid,
    route_id uuid,
    driver_id uuid,
    trip_number integer
);


ALTER TABLE test_tenant_schema.trips OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.users (
    id uuid NOT NULL,
    username character varying(50) NOT NULL,
    email character varying(100),
    password_hash character varying(255) NOT NULL,
    is_active boolean,
    role_id uuid NOT NULL
);


ALTER TABLE test_tenant_schema.users OWNER TO postgres;

--
-- Name: vehicles; Type: TABLE; Schema: test_tenant_schema; Owner: postgres
--

CREATE TABLE test_tenant_schema.vehicles (
    id uuid NOT NULL,
    name character varying,
    registration_number character varying,
    vehicle_type character varying,
    last_inspected_date date,
    pollution_renewal_date date,
    is_active boolean
);


ALTER TABLE test_tenant_schema.vehicles OWNER TO postgres;

--
-- Name: academic_years academic_years_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.academic_years
    ADD CONSTRAINT academic_years_pkey PRIMARY KEY (id);


--
-- Name: academic_years academic_years_title_key; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.academic_years
    ADD CONSTRAINT academic_years_title_key UNIQUE (title);


--
-- Name: alembic_version alembic_version_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.alembic_version
    ADD CONSTRAINT alembic_version_pkey PRIMARY KEY (version_num);


--
-- Name: certificate_types certificate_types_name_key; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.certificate_types
    ADD CONSTRAINT certificate_types_name_key UNIQUE (name);


--
-- Name: certificate_types certificate_types_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.certificate_types
    ADD CONSTRAINT certificate_types_pkey PRIMARY KEY (id);


--
-- Name: class_subject_mappings class_subject_mappings_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.class_subject_mappings
    ADD CONSTRAINT class_subject_mappings_pkey PRIMARY KEY (id);


--
-- Name: classes classes_name_key; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.classes
    ADD CONSTRAINT classes_name_key UNIQUE (name);


--
-- Name: classes classes_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.classes
    ADD CONSTRAINT classes_pkey PRIMARY KEY (id);


--
-- Name: designations designations_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.designations
    ADD CONSTRAINT designations_pkey PRIMARY KEY (id);


--
-- Name: designations designations_title_key; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.designations
    ADD CONSTRAINT designations_title_key UNIQUE (title);


--
-- Name: expense_attachments expense_attachments_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.expense_attachments
    ADD CONSTRAINT expense_attachments_pkey PRIMARY KEY (id);


--
-- Name: expense_attachments expense_attachments_stored_filename_key; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.expense_attachments
    ADD CONSTRAINT expense_attachments_stored_filename_key UNIQUE (stored_filename);


--
-- Name: expense_audit_logs expense_audit_logs_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.expense_audit_logs
    ADD CONSTRAINT expense_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: expense_categories expense_categories_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.expense_categories
    ADD CONSTRAINT expense_categories_pkey PRIMARY KEY (id);


--
-- Name: expense_settings expense_settings_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.expense_settings
    ADD CONSTRAINT expense_settings_pkey PRIMARY KEY (id);


--
-- Name: expense_transaction_items expense_transaction_items_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.expense_transaction_items
    ADD CONSTRAINT expense_transaction_items_pkey PRIMARY KEY (id);


--
-- Name: expense_transactions expense_transactions_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.expense_transactions
    ADD CONSTRAINT expense_transactions_pkey PRIMARY KEY (id);


--
-- Name: expense_types expense_types_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.expense_types
    ADD CONSTRAINT expense_types_pkey PRIMARY KEY (id);


--
-- Name: fee_categories fee_categories_category_name_academic_year_id_key; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.fee_categories
    ADD CONSTRAINT fee_categories_category_name_academic_year_id_key UNIQUE (category_name, academic_year_id);


--
-- Name: fee_categories fee_categories_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.fee_categories
    ADD CONSTRAINT fee_categories_pkey PRIMARY KEY (id);


--
-- Name: fee_class_map_term_amounts fee_class_map_term_amounts_fee_class_mapping_id_term_id_key; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.fee_class_map_term_amounts
    ADD CONSTRAINT fee_class_map_term_amounts_fee_class_mapping_id_term_id_key UNIQUE (fee_class_mapping_id, term_id);


--
-- Name: fee_class_map_term_amounts fee_class_map_term_amounts_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.fee_class_map_term_amounts
    ADD CONSTRAINT fee_class_map_term_amounts_pkey PRIMARY KEY (id);


--
-- Name: fee_class_mappings fee_class_mappings_class_id_fee_type_id_academic_year_id_key; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.fee_class_mappings
    ADD CONSTRAINT fee_class_mappings_class_id_fee_type_id_academic_year_id_key UNIQUE (class_id, fee_type_id, academic_year_id);


--
-- Name: fee_class_mappings fee_class_mappings_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.fee_class_mappings
    ADD CONSTRAINT fee_class_mappings_pkey PRIMARY KEY (id);


--
-- Name: fee_receipts fee_receipts_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.fee_receipts
    ADD CONSTRAINT fee_receipts_pkey PRIMARY KEY (id);


--
-- Name: fee_refunds fee_refunds_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.fee_refunds
    ADD CONSTRAINT fee_refunds_pkey PRIMARY KEY (id);


--
-- Name: fee_term_dates fee_term_dates_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.fee_term_dates
    ADD CONSTRAINT fee_term_dates_pkey PRIMARY KEY (id);


--
-- Name: fee_terms fee_terms_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.fee_terms
    ADD CONSTRAINT fee_terms_pkey PRIMARY KEY (id);


--
-- Name: fee_transaction_items fee_transaction_items_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.fee_transaction_items
    ADD CONSTRAINT fee_transaction_items_pkey PRIMARY KEY (id);


--
-- Name: fee_transactions fee_transactions_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.fee_transactions
    ADD CONSTRAINT fee_transactions_pkey PRIMARY KEY (id);


--
-- Name: fee_types fee_types_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.fee_types
    ADD CONSTRAINT fee_types_pkey PRIMARY KEY (id);


--
-- Name: fee_types fee_types_type_name_fee_category_id_key; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.fee_types
    ADD CONSTRAINT fee_types_type_name_fee_category_id_key UNIQUE (type_name, fee_category_id);


--
-- Name: holidays holidays_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.holidays
    ADD CONSTRAINT holidays_pkey PRIMARY KEY (id);


--
-- Name: menus menus_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.menus
    ADD CONSTRAINT menus_pkey PRIMARY KEY (id);


--
-- Name: parents parents_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.parents
    ADD CONSTRAINT parents_pkey PRIMARY KEY (id);


--
-- Name: parents parents_user_id_key; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.parents
    ADD CONSTRAINT parents_user_id_key UNIQUE (user_id);


--
-- Name: resource_permissions resource_permissions_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.resource_permissions
    ADD CONSTRAINT resource_permissions_pkey PRIMARY KEY (id);


--
-- Name: resource_permissions resource_permissions_role_id_resource_action_key; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.resource_permissions
    ADD CONSTRAINT resource_permissions_role_id_resource_action_key UNIQUE (role_id, resource, action);


--
-- Name: role_inheritance role_inheritance_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.role_inheritance
    ADD CONSTRAINT role_inheritance_pkey PRIMARY KEY (id);


--
-- Name: role_inheritance role_inheritance_tenant_role_id_key; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.role_inheritance
    ADD CONSTRAINT role_inheritance_tenant_role_id_key UNIQUE (tenant_role_id);


--
-- Name: role_menu_permissions role_menu_permissions_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.role_menu_permissions
    ADD CONSTRAINT role_menu_permissions_pkey PRIMARY KEY (id);


--
-- Name: roles roles_name_key; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.roles
    ADD CONSTRAINT roles_name_key UNIQUE (name);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: route_stops route_stops_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.route_stops
    ADD CONSTRAINT route_stops_pkey PRIMARY KEY (id);


--
-- Name: routes routes_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.routes
    ADD CONSTRAINT routes_pkey PRIMARY KEY (id);


--
-- Name: sections sections_name_key; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.sections
    ADD CONSTRAINT sections_name_key UNIQUE (name);


--
-- Name: sections sections_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.sections
    ADD CONSTRAINT sections_pkey PRIMARY KEY (id);


--
-- Name: slot_times slot_times_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.slot_times
    ADD CONSTRAINT slot_times_pkey PRIMARY KEY (id);


--
-- Name: staff_attendance staff_attendance_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.staff_attendance
    ADD CONSTRAINT staff_attendance_pkey PRIMARY KEY (id);


--
-- Name: staff_attendance staff_attendance_staff_id_date_key; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.staff_attendance
    ADD CONSTRAINT staff_attendance_staff_id_date_key UNIQUE (staff_id, date);


--
-- Name: staff staff_email_key; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.staff
    ADD CONSTRAINT staff_email_key UNIQUE (email);


--
-- Name: staff staff_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.staff
    ADD CONSTRAINT staff_pkey PRIMARY KEY (id);


--
-- Name: staff staff_user_id_key; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.staff
    ADD CONSTRAINT staff_user_id_key UNIQUE (user_id);


--
-- Name: student_admissions student_admissions_admission_number_key; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.student_admissions
    ADD CONSTRAINT student_admissions_admission_number_key UNIQUE (admission_number);


--
-- Name: student_admissions student_admissions_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.student_admissions
    ADD CONSTRAINT student_admissions_pkey PRIMARY KEY (id);


--
-- Name: student_attendance student_attendance_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.student_attendance
    ADD CONSTRAINT student_attendance_pkey PRIMARY KEY (id);


--
-- Name: student_certificates student_certificates_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.student_certificates
    ADD CONSTRAINT student_certificates_pkey PRIMARY KEY (id);


--
-- Name: student_documents student_documents_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.student_documents
    ADD CONSTRAINT student_documents_pkey PRIMARY KEY (id);


--
-- Name: student_homework student_homework_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.student_homework
    ADD CONSTRAINT student_homework_pkey PRIMARY KEY (id);


--
-- Name: student_parent_links student_parent_links_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.student_parent_links
    ADD CONSTRAINT student_parent_links_pkey PRIMARY KEY (id);


--
-- Name: student_transport_assignments student_transport_assignments_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.student_transport_assignments
    ADD CONSTRAINT student_transport_assignments_pkey PRIMARY KEY (id);


--
-- Name: student_trips student_trips_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.student_trips
    ADD CONSTRAINT student_trips_pkey PRIMARY KEY (id);


--
-- Name: students students_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.students
    ADD CONSTRAINT students_pkey PRIMARY KEY (id);


--
-- Name: students students_user_id_key; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.students
    ADD CONSTRAINT students_user_id_key UNIQUE (user_id);


--
-- Name: subject_categories subject_categories_name_key; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.subject_categories
    ADD CONSTRAINT subject_categories_name_key UNIQUE (name);


--
-- Name: subject_categories subject_categories_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.subject_categories
    ADD CONSTRAINT subject_categories_pkey PRIMARY KEY (id);


--
-- Name: subjects subjects_name_key; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.subjects
    ADD CONSTRAINT subjects_name_key UNIQUE (name);


--
-- Name: subjects subjects_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.subjects
    ADD CONSTRAINT subjects_pkey PRIMARY KEY (id);


--
-- Name: timetable_slots timetable_slots_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.timetable_slots
    ADD CONSTRAINT timetable_slots_pkey PRIMARY KEY (id);


--
-- Name: timetable_subject_options timetable_subject_options_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.timetable_subject_options
    ADD CONSTRAINT timetable_subject_options_pkey PRIMARY KEY (id);


--
-- Name: timetables timetables_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.timetables
    ADD CONSTRAINT timetables_pkey PRIMARY KEY (id);


--
-- Name: timetables timetables_section_id_key; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.timetables
    ADD CONSTRAINT timetables_section_id_key UNIQUE (section_id);


--
-- Name: trips trips_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.trips
    ADD CONSTRAINT trips_pkey PRIMARY KEY (id);


--
-- Name: expense_settings uq_expense_setting_key; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.expense_settings
    ADD CONSTRAINT uq_expense_setting_key UNIQUE (setting_key);


--
-- Name: expense_transactions uq_expense_transaction_idempotency; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.expense_transactions
    ADD CONSTRAINT uq_expense_transaction_idempotency UNIQUE (idempotency_key);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: vehicles vehicles_pkey; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.vehicles
    ADD CONSTRAINT vehicles_pkey PRIMARY KEY (id);


--
-- Name: vehicles vehicles_registration_number_key; Type: CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.vehicles
    ADD CONSTRAINT vehicles_registration_number_key UNIQUE (registration_number);


--
-- Name: academic_years_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX academic_years_id_idx ON test_tenant_schema.academic_years USING btree (id);


--
-- Name: certificate_types_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX certificate_types_id_idx ON test_tenant_schema.certificate_types USING btree (id);


--
-- Name: class_subject_mappings_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX class_subject_mappings_id_idx ON test_tenant_schema.class_subject_mappings USING btree (id);


--
-- Name: classes_academic_year_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX classes_academic_year_id_idx ON test_tenant_schema.classes USING btree (academic_year_id);


--
-- Name: classes_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX classes_id_idx ON test_tenant_schema.classes USING btree (id);


--
-- Name: designations_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX designations_id_idx ON test_tenant_schema.designations USING btree (id);


--
-- Name: fee_categories_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX fee_categories_id_idx ON test_tenant_schema.fee_categories USING btree (id);


--
-- Name: fee_class_map_term_amounts_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX fee_class_map_term_amounts_id_idx ON test_tenant_schema.fee_class_map_term_amounts USING btree (id);


--
-- Name: fee_class_mappings_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX fee_class_mappings_id_idx ON test_tenant_schema.fee_class_mappings USING btree (id);


--
-- Name: fee_term_dates_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX fee_term_dates_id_idx ON test_tenant_schema.fee_term_dates USING btree (id);


--
-- Name: fee_term_dates_term_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX fee_term_dates_term_id_idx ON test_tenant_schema.fee_term_dates USING btree (term_id);


--
-- Name: fee_terms_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX fee_terms_id_idx ON test_tenant_schema.fee_terms USING btree (id);


--
-- Name: fee_types_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX fee_types_id_idx ON test_tenant_schema.fee_types USING btree (id);


--
-- Name: holidays_academic_year_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX holidays_academic_year_id_idx ON test_tenant_schema.holidays USING btree (academic_year_id);


--
-- Name: holidays_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX holidays_id_idx ON test_tenant_schema.holidays USING btree (id);


--
-- Name: idx_fee_trans_academic_year; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX idx_fee_trans_academic_year ON test_tenant_schema.fee_transactions USING btree (academic_year_id, transaction_date);


--
-- Name: idx_fee_trans_item_fee_type; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX idx_fee_trans_item_fee_type ON test_tenant_schema.fee_transaction_items USING btree (fee_type_id, fee_term_id);


--
-- Name: idx_fee_trans_item_transaction; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX idx_fee_trans_item_transaction ON test_tenant_schema.fee_transaction_items USING btree (fee_transaction_id);


--
-- Name: idx_fee_trans_status_method; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX idx_fee_trans_status_method ON test_tenant_schema.fee_transactions USING btree (status, payment_method);


--
-- Name: idx_fee_trans_student_date; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX idx_fee_trans_student_date ON test_tenant_schema.fee_transactions USING btree (student_id, transaction_date);


--
-- Name: ix_expense_attachments_department_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_attachments_department_id ON test_tenant_schema.expense_attachments USING btree (department_id);


--
-- Name: ix_expense_attachments_file_hash_sha256; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_attachments_file_hash_sha256 ON test_tenant_schema.expense_attachments USING btree (file_hash_sha256);


--
-- Name: ix_expense_attachments_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_attachments_id ON test_tenant_schema.expense_attachments USING btree (id);


--
-- Name: ix_expense_attachments_org_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_attachments_org_id ON test_tenant_schema.expense_attachments USING btree (org_id);


--
-- Name: ix_expense_attachments_transaction_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_attachments_transaction_id ON test_tenant_schema.expense_attachments USING btree (transaction_id);


--
-- Name: ix_expense_attachments_uploaded_by_user_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_attachments_uploaded_by_user_id ON test_tenant_schema.expense_attachments USING btree (uploaded_by_user_id);


--
-- Name: ix_expense_audit_logs_action; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_audit_logs_action ON test_tenant_schema.expense_audit_logs USING btree (action);


--
-- Name: ix_expense_audit_logs_action_category; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_audit_logs_action_category ON test_tenant_schema.expense_audit_logs USING btree (action_category);


--
-- Name: ix_expense_audit_logs_actor_role; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_audit_logs_actor_role ON test_tenant_schema.expense_audit_logs USING btree (actor_role);


--
-- Name: ix_expense_audit_logs_actor_user_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_audit_logs_actor_user_id ON test_tenant_schema.expense_audit_logs USING btree (actor_user_id);


--
-- Name: ix_expense_audit_logs_created_at; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_audit_logs_created_at ON test_tenant_schema.expense_audit_logs USING btree (created_at);


--
-- Name: ix_expense_audit_logs_department_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_audit_logs_department_id ON test_tenant_schema.expense_audit_logs USING btree (department_id);


--
-- Name: ix_expense_audit_logs_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_audit_logs_id ON test_tenant_schema.expense_audit_logs USING btree (id);


--
-- Name: ix_expense_audit_logs_org_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_audit_logs_org_id ON test_tenant_schema.expense_audit_logs USING btree (org_id);


--
-- Name: ix_expense_audit_logs_transaction_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_audit_logs_transaction_id ON test_tenant_schema.expense_audit_logs USING btree (transaction_id);


--
-- Name: ix_expense_categories_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_categories_id ON test_tenant_schema.expense_categories USING btree (id);


--
-- Name: ix_expense_categories_org_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_categories_org_id ON test_tenant_schema.expense_categories USING btree (org_id);


--
-- Name: ix_expense_settings_created_by_user_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_settings_created_by_user_id ON test_tenant_schema.expense_settings USING btree (created_by_user_id);


--
-- Name: ix_expense_settings_department_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_settings_department_id ON test_tenant_schema.expense_settings USING btree (department_id);


--
-- Name: ix_expense_settings_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_settings_id ON test_tenant_schema.expense_settings USING btree (id);


--
-- Name: ix_expense_settings_org_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_settings_org_id ON test_tenant_schema.expense_settings USING btree (org_id);


--
-- Name: ix_expense_settings_setting_category; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_settings_setting_category ON test_tenant_schema.expense_settings USING btree (setting_category);


--
-- Name: ix_expense_settings_setting_key; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_settings_setting_key ON test_tenant_schema.expense_settings USING btree (setting_key);


--
-- Name: ix_expense_transaction_items_created_by_user_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_transaction_items_created_by_user_id ON test_tenant_schema.expense_transaction_items USING btree (created_by_user_id);


--
-- Name: ix_expense_transaction_items_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_transaction_items_id ON test_tenant_schema.expense_transaction_items USING btree (id);


--
-- Name: ix_expense_transaction_items_org_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_transaction_items_org_id ON test_tenant_schema.expense_transaction_items USING btree (org_id);


--
-- Name: ix_expense_transaction_items_transaction_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_transaction_items_transaction_id ON test_tenant_schema.expense_transaction_items USING btree (transaction_id);


--
-- Name: ix_expense_transactions_created_by_user_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_transactions_created_by_user_id ON test_tenant_schema.expense_transactions USING btree (created_by_user_id);


--
-- Name: ix_expense_transactions_department_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_transactions_department_id ON test_tenant_schema.expense_transactions USING btree (department_id);


--
-- Name: ix_expense_transactions_expense_type_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_transactions_expense_type_id ON test_tenant_schema.expense_transactions USING btree (expense_type_id);


--
-- Name: ix_expense_transactions_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_transactions_id ON test_tenant_schema.expense_transactions USING btree (id);


--
-- Name: ix_expense_transactions_org_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_transactions_org_id ON test_tenant_schema.expense_transactions USING btree (org_id);


--
-- Name: ix_expense_transactions_status; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_transactions_status ON test_tenant_schema.expense_transactions USING btree (status);


--
-- Name: ix_expense_transactions_transaction_date; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_transactions_transaction_date ON test_tenant_schema.expense_transactions USING btree (transaction_date);


--
-- Name: ix_expense_transactions_vendor_name; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_transactions_vendor_name ON test_tenant_schema.expense_transactions USING btree (vendor_name);


--
-- Name: ix_expense_types_category_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_types_category_id ON test_tenant_schema.expense_types USING btree (category_id);


--
-- Name: ix_expense_types_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_types_id ON test_tenant_schema.expense_types USING btree (id);


--
-- Name: ix_expense_types_org_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_expense_types_org_id ON test_tenant_schema.expense_types USING btree (org_id);


--
-- Name: ix_fee_receipts_fee_transaction_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_fee_receipts_fee_transaction_id ON test_tenant_schema.fee_receipts USING btree (fee_transaction_id);


--
-- Name: ix_fee_receipts_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX ix_fee_receipts_id ON test_tenant_schema.fee_receipts USING btree (id);


--
-- Name: ix_fee_receipts_receipt_number; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX ix_fee_receipts_receipt_number ON test_tenant_schema.fee_receipts USING btree (receipt_number);


--
-- Name: ix_fee_refunds_fee_transaction_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_fee_refunds_fee_transaction_id ON test_tenant_schema.fee_refunds USING btree (fee_transaction_id);


--
-- Name: ix_fee_refunds_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX ix_fee_refunds_id ON test_tenant_schema.fee_refunds USING btree (id);


--
-- Name: ix_fee_refunds_refund_number; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX ix_fee_refunds_refund_number ON test_tenant_schema.fee_refunds USING btree (refund_number);


--
-- Name: ix_fee_refunds_student_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_fee_refunds_student_id ON test_tenant_schema.fee_refunds USING btree (student_id);


--
-- Name: ix_fee_transaction_items_fee_term_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_fee_transaction_items_fee_term_id ON test_tenant_schema.fee_transaction_items USING btree (fee_term_id);


--
-- Name: ix_fee_transaction_items_fee_transaction_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_fee_transaction_items_fee_transaction_id ON test_tenant_schema.fee_transaction_items USING btree (fee_transaction_id);


--
-- Name: ix_fee_transaction_items_fee_type_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_fee_transaction_items_fee_type_id ON test_tenant_schema.fee_transaction_items USING btree (fee_type_id);


--
-- Name: ix_fee_transaction_items_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX ix_fee_transaction_items_id ON test_tenant_schema.fee_transaction_items USING btree (id);


--
-- Name: ix_fee_transactions_academic_year_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_fee_transactions_academic_year_id ON test_tenant_schema.fee_transactions USING btree (academic_year_id);


--
-- Name: ix_fee_transactions_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX ix_fee_transactions_id ON test_tenant_schema.fee_transactions USING btree (id);


--
-- Name: ix_fee_transactions_student_admission_num; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_fee_transactions_student_admission_num ON test_tenant_schema.fee_transactions USING btree (student_admission_num);


--
-- Name: ix_fee_transactions_student_id; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE INDEX ix_fee_transactions_student_id ON test_tenant_schema.fee_transactions USING btree (student_id);


--
-- Name: ix_fee_transactions_transaction_number; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX ix_fee_transactions_transaction_number ON test_tenant_schema.fee_transactions USING btree (transaction_number);


--
-- Name: menus_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX menus_id_idx ON test_tenant_schema.menus USING btree (id);


--
-- Name: parents_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX parents_id_idx ON test_tenant_schema.parents USING btree (id);


--
-- Name: resource_permissions_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX resource_permissions_id_idx ON test_tenant_schema.resource_permissions USING btree (id);


--
-- Name: role_inheritance_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX role_inheritance_id_idx ON test_tenant_schema.role_inheritance USING btree (id);


--
-- Name: role_menu_permissions_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX role_menu_permissions_id_idx ON test_tenant_schema.role_menu_permissions USING btree (id);


--
-- Name: roles_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX roles_id_idx ON test_tenant_schema.roles USING btree (id);


--
-- Name: route_stops_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX route_stops_id_idx ON test_tenant_schema.route_stops USING btree (id);


--
-- Name: routes_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX routes_id_idx ON test_tenant_schema.routes USING btree (id);


--
-- Name: sections_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX sections_id_idx ON test_tenant_schema.sections USING btree (id);


--
-- Name: slot_times_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX slot_times_id_idx ON test_tenant_schema.slot_times USING btree (id);


--
-- Name: staff_attendance_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX staff_attendance_id_idx ON test_tenant_schema.staff_attendance USING btree (id);


--
-- Name: staff_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX staff_id_idx ON test_tenant_schema.staff USING btree (id);


--
-- Name: student_admissions_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX student_admissions_id_idx ON test_tenant_schema.student_admissions USING btree (id);


--
-- Name: student_attendance_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX student_attendance_id_idx ON test_tenant_schema.student_attendance USING btree (id);


--
-- Name: student_certificates_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX student_certificates_id_idx ON test_tenant_schema.student_certificates USING btree (id);


--
-- Name: student_documents_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX student_documents_id_idx ON test_tenant_schema.student_documents USING btree (id);


--
-- Name: student_homework_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX student_homework_id_idx ON test_tenant_schema.student_homework USING btree (id);


--
-- Name: student_parent_links_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX student_parent_links_id_idx ON test_tenant_schema.student_parent_links USING btree (id);


--
-- Name: student_transport_assignments_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX student_transport_assignments_id_idx ON test_tenant_schema.student_transport_assignments USING btree (id);


--
-- Name: student_trips_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX student_trips_id_idx ON test_tenant_schema.student_trips USING btree (id);


--
-- Name: students_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX students_id_idx ON test_tenant_schema.students USING btree (id);


--
-- Name: subject_categories_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX subject_categories_id_idx ON test_tenant_schema.subject_categories USING btree (id);


--
-- Name: subjects_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX subjects_id_idx ON test_tenant_schema.subjects USING btree (id);


--
-- Name: timetable_slots_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX timetable_slots_id_idx ON test_tenant_schema.timetable_slots USING btree (id);


--
-- Name: timetable_subject_options_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX timetable_subject_options_id_idx ON test_tenant_schema.timetable_subject_options USING btree (id);


--
-- Name: timetables_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX timetables_id_idx ON test_tenant_schema.timetables USING btree (id);


--
-- Name: trips_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX trips_id_idx ON test_tenant_schema.trips USING btree (id);


--
-- Name: users_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX users_id_idx ON test_tenant_schema.users USING btree (id);


--
-- Name: vehicles_id_idx; Type: INDEX; Schema: test_tenant_schema; Owner: postgres
--

CREATE UNIQUE INDEX vehicles_id_idx ON test_tenant_schema.vehicles USING btree (id);


--
-- Name: expense_attachments expense_attachments_transaction_id_fkey; Type: FK CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.expense_attachments
    ADD CONSTRAINT expense_attachments_transaction_id_fkey FOREIGN KEY (transaction_id) REFERENCES test_tenant_schema.expense_transactions(id);


--
-- Name: expense_audit_logs expense_audit_logs_transaction_id_fkey; Type: FK CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.expense_audit_logs
    ADD CONSTRAINT expense_audit_logs_transaction_id_fkey FOREIGN KEY (transaction_id) REFERENCES test_tenant_schema.expense_transactions(id);


--
-- Name: expense_transaction_items expense_transaction_items_transaction_id_fkey; Type: FK CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.expense_transaction_items
    ADD CONSTRAINT expense_transaction_items_transaction_id_fkey FOREIGN KEY (transaction_id) REFERENCES test_tenant_schema.expense_transactions(id);


--
-- Name: expense_transactions expense_transactions_expense_type_id_fkey; Type: FK CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.expense_transactions
    ADD CONSTRAINT expense_transactions_expense_type_id_fkey FOREIGN KEY (expense_type_id) REFERENCES test_tenant_schema.expense_types(id);


--
-- Name: expense_types expense_types_category_id_fkey; Type: FK CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.expense_types
    ADD CONSTRAINT expense_types_category_id_fkey FOREIGN KEY (category_id) REFERENCES test_tenant_schema.expense_categories(id);


--
-- Name: fee_receipts fee_receipts_fee_transaction_id_fkey; Type: FK CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.fee_receipts
    ADD CONSTRAINT fee_receipts_fee_transaction_id_fkey FOREIGN KEY (fee_transaction_id) REFERENCES test_tenant_schema.fee_transactions(id);


--
-- Name: fee_refunds fee_refunds_fee_transaction_id_fkey; Type: FK CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.fee_refunds
    ADD CONSTRAINT fee_refunds_fee_transaction_id_fkey FOREIGN KEY (fee_transaction_id) REFERENCES test_tenant_schema.fee_transactions(id);


--
-- Name: fee_transaction_items fee_transaction_items_fee_transaction_id_fkey; Type: FK CONSTRAINT; Schema: test_tenant_schema; Owner: postgres
--

ALTER TABLE ONLY test_tenant_schema.fee_transaction_items
    ADD CONSTRAINT fee_transaction_items_fee_transaction_id_fkey FOREIGN KEY (fee_transaction_id) REFERENCES test_tenant_schema.fee_transactions(id);


--
-- PostgreSQL database dump complete
--

